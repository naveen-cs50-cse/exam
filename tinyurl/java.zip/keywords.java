class Person {
    String name = "Parent Name";
    void display() {
        System.out.println("Display method in Person class");
    }
}
class Student extends Person {
    String name = "Child Name";
    void showNames() {
        System.out.println("Using this: " + this.name);   
        System.out.println("Using super: " + super.name);
    }
    void display() {
        super.display();  
        System.out.println("Display method in Student class");
    }
}


final class FinalClass {
    final int value = 10; 

    final void showValue() { 
        System.out.println("Final value: " + value);
    }
}

class Keywords {
    public static void main(String[] args) {
        Student s = new Student();
        s.showNames();
        s.display();
        FinalClass f = new FinalClass();
        f.showValue();
    }
}
