 class StringDemo {
    public static void main(String[] args) {

       
        // 1. String (Immutable)
        String s1 = "Hello";
        s1.concat(" World");   
        System.out.println("String (Immutable): " + s1);
        // 2. StringBuffer 
        StringBuffer sb = new StringBuffer("Hello");
        sb.append(" World");   
        System.out.println("StringBuffer: " + sb);
         // 3. StringBuilder 
        StringBuilder sb2 = new StringBuilder("Hello");
        sb2.append(" World");  
        System.out.println("StringBuilder: " + sb2);
    }
}
