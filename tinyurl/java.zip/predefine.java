import java.util.*;
class predefine{
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int x = sc.nextInt();
        System.out.println("You entered: " + x);
    }
}
