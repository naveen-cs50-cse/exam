 class AgeException extends Exception {
    public AgeException(String message) {
        super(message);
    }
 }
 public class Customexceptiondemo{
    static void checkAge(int age) throws AgeException {
        if (age < 18) {
            throw new AgeException("Age is less than 18 and not eligible to vote!");
        } else {
            System.out.println(“Age is ” +age+ “ ,and eligible to vote”);
        }
    }
    public static void main(String[] args) {
        int age1 = 15; 
        int age2 = 20; 
        try {
            checkAge(age1); // This throws AgeException
        } catch (AgeException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed after first check.\n");
        }
        try {
            checkAge(age2); // This does not throw exception
        } catch (AgeException e) {
            System.out.println("Caught Exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed after second check.");
        }
    }
 }