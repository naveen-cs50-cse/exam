public class Student {

    int rollNo;
    String name;
    String course;

    Student() {
        rollNo = 0;
        name = "Unknown";
        course = "Not Assigned";
    }

    Student(int r) {
        rollNo = r;
        name = "Unknown";
        course = "Not Assigned";
    }
    Student(int r, String n, String c) {
        rollNo = r;
        name = n;
        course = c;
    }

    void display() {
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Course: " + course);
    }
}

 class constructoroverloading {
    public static void main(String[] args) {

        Student s1 = new Student();                          
        Student s2 = new Student(101);                      
        Student s3 = new Student(102, "Rahul", "Java");      

        s1.display();
        s2.display();
        s3.display();
    }
}
