
class Student {
    int rollNo;
    String name;
    String course;

    void displayDetails() {
        System.out.println("Student Details:");
        System.out.println("Roll Number: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Course: " + course);
    }
}
 class StudentDemo {
    public static void main(String[] args) {

        Student s1 = new Student();
        s1.rollNo = 101;
        s1.name = "Rahul";
        s1.course = "cse ds";
        s1.displayDetails();
    }
}
