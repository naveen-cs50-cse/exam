package mypack;
public class A
{
public void show()
{
System.out.println("Sum method");
}
}