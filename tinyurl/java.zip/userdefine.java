import mypack.A;
public class userdefine
{
public static void main(String args[])
{
A a=new A();
a.show();
System.out.println("show() class A");
}
}