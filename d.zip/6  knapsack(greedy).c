#include <stdio.h>

int main() {
    int n, i, j;
    float w[10], p[10], ratio[10], cap, temp;

    printf("Enter number of items: ");
    scanf("%d", &n);

    printf("Enter weights:\n");
    for(i=0;i<n;i++)
        scanf("%f",&w[i]);

    printf("Enter profits:\n");
    for(i=0;i<n;i++)
        scanf("%f",&p[i]);

    printf("Enter capacity: ");
    scanf("%f",&cap);

    for(i=0;i<n;i++)
        ratio[i]=p[i]/w[i];

    // Sort by ratio
    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
            if(ratio[j]<ratio[j+1])
            {
                // 3 same but diff names
                temp=ratio[j]; 
                ratio[j]=ratio[j+1]; 
                ratio[j+1]=temp;

                temp=w[j]; 
                w[j]=w[j+1]; 
                w[j+1]=temp;


                temp=p[j]; 
                p[j]=p[j+1]; 
                p[j+1]=temp;
            }

    float profit=0;

    for(i=0;i<n;i++)
    {
        if(w[i]<=cap)
        {
            cap-=w[i];
            profit+=p[i];
        }
        else
        {
            profit+=cap*(p[i]/w[i]);
            break;
        }
    }

    printf("Maximum Profit = %.2f",profit);

    return 0;
}