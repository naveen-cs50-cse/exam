#include <stdio.h>

int g[10][10], color[10], n, m;

int safe(int v,int c)
{
    for(int i=1;i<=n;i++)
        if(g[v][i] && color[i]==c)
            return 0;
    return 1;
}

void graphcolor(int v)
{
    if(v>n)
    {
        for(int i=1;i<=n;i++)
            printf("%d ",color[i]);
        printf("\n");
        return;
    }

    for(int c=1;c<=m;c++)
    {
        if(safe(v,c))
        {
            color[v]=c;
            graphcolor(v+1);
            color[v]=0;
        }
    }
}

int main()
{
    printf("Enter number of vertices: ");
    scanf("%d",&n);

    printf("Enter number of colors: ");
    scanf("%d",&m);

    printf("Enter adjacency matrix:\n");

    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            scanf("%d",&g[i][j]);

    graphcolor(1);

    return 0;
}