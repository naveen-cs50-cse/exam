#include <stdio.h>

int parent[10];

int find(int x)
{
    while(parent[x]!=0)
        x=parent[x];
    return x;
}

int main()
{
    int n,cost[10][10];
    int i,j,min,u,v,mincost=0,edges=1;

    printf("Enter number of vertices: ");
    scanf("%d",&n);

    printf("Enter cost matrix:\n");
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            scanf("%d",&cost[i][j]);
            if(cost[i][j]==0)
                cost[i][j]=999;
        }
    }

    while(edges<n)
    {
        min=999;

        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(cost[i][j]<min)
                {
                    min=cost[i][j];
                    u=i;
                    v=j;
                }
            }
        }

        if(find(u)!=find(v))
        {
            parent[find(u)]=find(v);
            printf("%d - %d = %d\n",u,v,min);
            mincost+=min;
            edges++;
        }

        cost[u][v]=cost[v][u]=999;
    }

    printf("Minimum Cost = %d",mincost);

    return 0;
}       