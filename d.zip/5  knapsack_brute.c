#include <stdio.h>

int max(int a, int b)
{
    return (a > b) ? a : b;
}

int knapsack(int w[], int p[], int n, int c)
{
    if(n == 0 || c == 0)
        return 0;

    if(w[n-1] > c)
        return knapsack(w, p, n-1, c);

    return max(p[n-1] + knapsack(w, p, n-1, c-w[n-1] ),
                        knapsack(w, p, n-1, c) );
}

int main()
{
    int w[] = {10,20,30};
    int p[] = {60,100,120};

    printf("Maximum Profit = %d", knapsack(w,p,3,50));

    return 0;
}