#include <stdio.h>

int main()
{
    int n,cost[10][10],visited[10]={0};
    int i,j,min,u,v,mincost=0;

    printf("Enter number of vertices: ");
    scanf("%d",&n);

    printf("Enter cost matrix:\n");

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            scanf("%d",&cost[i][j]);

            if(cost[i][j]==0)
                cost[i][j]=999;
        }
    }

    visited[1]=1;

    for(int edge=1;edge<n;edge++)
    {
        min=999;

        for(i=1;i<=n;i++)
        {
            if(visited[i])
            {
                for(j=1;j<=n;j++)
                {
                    if(!visited[j] && cost[i][j]<min)
                    {
                        min=cost[i][j];
                        u=i;
                        v=j;
                    }
                }
            }
        }

        printf("%d - %d = %d\n",u,v,min);

        mincost+=min;

        visited[v]=1;
    }

    printf("Minimum Cost = %d",mincost);

    return 0;
}