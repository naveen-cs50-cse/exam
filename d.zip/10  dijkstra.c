#include <stdio.h>

#define INF 999

int main()
{
    int n, cost[10][10], dist[10], visited[10]={0};
    int i, j, source, min, u;

    printf("Enter number of vertices: ");
    scanf("%d",&n);

    printf("Enter cost matrix:\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&cost[i][j]);

            if(cost[i][j]==0 && i!=j)
                cost[i][j]=INF;
        }
    }

    printf("Enter source vertex: ");
    scanf("%d",&source);

    for(i=0;i<n;i++)
        dist[i]=cost[source][i];

    visited[source]=1;
    dist[source]=0;

    for(int count=1; count<n; count++)
    {
        min=INF;

        for(i=0;i<n;i++)
        {
            if(!visited[i] && dist[i]<min)
            {
                min=dist[i];
                u=i;
            }
        }

        visited[u]=1;

        for(i=0;i<n;i++)
        {
            if(!visited[i] && dist[u]+cost[u][i] < dist[i])
                dist[i]=dist[u]+cost[u][i];
        }
    }

    printf("\nShortest distances:\n");
    for(i=0;i<n;i++)
        printf("%d -> %d = %d\n",source,i,dist[i]);

    return 0;
}