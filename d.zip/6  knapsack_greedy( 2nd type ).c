#include <stdio.h>

int main()
{
    int weight[] = {10,20,30};
    int profit[] = {60,100,120};
    float ratio[] = {6,5,4};

    int capacity = 50;
    float total = 0;

    for(int i=0;i<3;i++)
    {
        if(capacity >= weight[i])
        {
            total += profit[i];
            capacity -= weight[i];
        }
        else
        {
            total += ratio[i] * capacity;
            break;
        }
    }

    printf("Maximum Profit = %.2f", total);

    return 0;
}