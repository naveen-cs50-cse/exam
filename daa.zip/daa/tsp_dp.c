//Travelling Salesmen Problem using Dynamic Programming Principle of Optimal equation
#include <stdio.h>
#include <limits.h>
int cost[20][20], dp[1025][20];
int n;
int tsp(int mask, int pos)
{if (mask == (1 << n) - 1)
return cost[pos][0];
if (dp[mask][pos] != -1)
return dp[mask][pos];
int ans = INT_MAX;
for (int city = 0; city < n; city++) {
if ((mask & (1 << city)) == 0) {
int newAns = cost[pos][city] + tsp(mask | (1 << city), city);
if (newAns < ans)
ans = newAns;
return dp[mask][pos] = ans;}}}
int main() {printf("Enter number of cities: ");
scanf("%d", &n);
printf("Enter cost adjacency matrix:\n");
for (int i = 0; i < n; i++)
for (int j = 0; j < n; j++)
scanf("%d", &cost[i][j]);
for (int i = 0; i < (1 << n); i++)
for (int j = 0; j < n; j++)
dp[i][j] = -1;
int result = tsp(1, 0);
printf("The minimum cost is: %d\n", result);
return 0;}