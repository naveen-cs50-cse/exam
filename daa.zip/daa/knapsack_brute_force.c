// Brute Force Approach
#include <stdio.h>
int max(int a, int b) {
return (a > b) ? a : b;}
int knapsack(int W, int wt[], int val[], int n) {
if (n == 0 || W == 0) {
return 0;}
if (wt[n - 1] > W) {
return knapsack(W, wt, val, n - 1);}
else {return max(val[n - 1] + knapsack(W - wt[n - 1], wt, val, n - 1),
knapsack(W, wt, val, n - 1));}}
int main() {int profit[] = {60, 100, 120,150,170,190,200,};
int weight[] = {10, 20, 30,40,15,50,45};
int W = 100; int n = sizeof(profit) / sizeof(profit[0]);
printf("Maximum Profit: %d\n", knapsack(W, weight, profit, n));
return 0;}