class Student { 
    String name;
    int rollno;
    float marks;

    void get() {
        name = "Ram";
        rollno = 1;
        marks = 540f;
    }

    void disp() { 
        System.out.println("Name = " + name);
        System.out.println("Roll no = " + rollno);
        System.out.println("Marks = " + marks);
    }
}

public class Main {
    public static void main(String[] args) {
        Student x = new Student();
        x.get();
        x.disp();
    }
}