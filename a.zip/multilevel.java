class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void disp() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

class Emp extends Person {
    double sal;

    Emp(String name, int age, double sal) {
        super(name, age);
        this.sal = sal;
    }

    void disp() {
        super.disp();
        System.out.println("Salary: " + sal);
    }
}

class Manager extends Emp {
    int teamSize;

    Manager(String name, int age, double sal, int teamSize) {
        super(name, age, sal);
        this.teamSize = teamSize;
    }

    void disp() {
        super.disp();
        System.out.println("Team Size: " + teamSize);
    }
}

public class Main {
    public static void main(String[] args) {
        Manager m = new Manager("Sreenith", 18, 200000, 4);
        m.disp();
    }
}