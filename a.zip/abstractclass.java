abstract class Figure {
    double pi = 3.14159;
    abstract void area();
    
    void abc() {
        System.out.println("Different method");
    }
}

class Circle extends Figure {
    double r = 4.5;
    void area() {
        System.out.println("The area of the circle is: " + (pi * r * r));
    }
}

class Rectangle extends Figure {
    double l = 4.5, b = 7.8;
    void area() {
        System.out.println("The area of the rectangle is: " + (l * b));
    }
}

public class Main {
    public static void main(String[] args) {
        Figure f = new Circle();
        f.area();
        f.abc();
        
        f = new Rectangle();
        f.area();
    }
}