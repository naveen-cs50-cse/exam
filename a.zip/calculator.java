import java.awt.*;
import java.awt.event.*;

public class Calc extends Frame implements ActionListener {
    TextField t1 = new TextField(10), t2 = new TextField(10);
    Button b1 = new Button("ADD"), b2 = new Button("SUB"), b3 = new Button("MUL"), b4 = new Button("DIV");
    Label l3 = new Label("Result:          ");

    public Calc() {
        setLayout(new FlowLayout());
        add(new Label("Num1:")); add(t1);
        add(new Label("Num2:")); add(t2);
        add(b1); add(b2); add(b3); add(b4); 
        add(l3);
        
        b1.addActionListener(this); 
        b2.addActionListener(this);
        b3.addActionListener(this); 
        b4.addActionListener(this);
        
        setSize(300, 200);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        int a = Integer.parseInt(t1.getText());
        int b = Integer.parseInt(t2.getText());
        String cmd = ae.getActionCommand();
        int c = 0;
        
        if (cmd.equals("ADD")) c = a + b;
        else if (cmd.equals("SUB")) c = a - b;
        else if (cmd.equals("MUL")) c = a * b;
        else if (cmd.equals("DIV")) c = a / b;
        
        l3.setText("Result: " + c);
    }

    public static void main(String[] args) { 
        new Calc(); 
    }
}