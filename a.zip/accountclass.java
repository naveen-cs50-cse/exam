import java.util.Scanner;

class Account {
    private String name;
    private int accNum;
    private double bal = 0.0;

    public Account(String name, int accNum) {
        this.name = name;
        this.accNum = accNum;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            bal += amount;
            System.out.println("Deposited: Rs " + amount); 
        } else {
            System.out.println("Deposit amount must be positive."); 
        } 
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= bal) {
            bal -= amount;
            System.out.println("Withdrew: Rs " + amount); 
        } else {
            System.out.println("Invalid withdrawal amount."); 
        } 
    }

    public void checkBal() {
        System.out.println("Current Balance: Rs " + bal); 
    }

    public void details() {
        System.out.println("Account Holder: " + name);
        System.out.println("Account Number: " + accNum);
        checkBal();
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter account holder name: "); 
        String name = sc.nextLine();
        System.out.print("Enter account number: "); 
        int accNumber = sc.nextInt();
        
        Account acc = new Account(name, accNumber); 
        int ch;
        
        do {
            System.out.println("\n1. Deposit  2. Withdraw  3. Check Balance  4. Details  5. Exit");
            System.out.print("Choice: "); 
            ch = sc.nextInt();
            
            switch (ch) {
                case 1 -> {
                    System.out.print("Amount to deposit: "); 
                    acc.deposit(sc.nextDouble());
                }
                case 2 -> {
                    System.out.print("Amount to withdraw: "); 
                    acc.withdraw(sc.nextDouble());
                }
                case 3 -> acc.checkBal();
                case 4 -> acc.details();
                case 5 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice."); 
            }
        } while (ch != 5);
    }
}