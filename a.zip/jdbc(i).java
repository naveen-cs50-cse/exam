import java.sql.*;
import java.util.Scanner;

public class StudentDBInit {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/test";
        String user = "root", pass = "";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             Statement st = con.createStatement();
             Scanner sc = new Scanner(System.in)) {
            
            String createTable = "CREATE TABLE IF NOT EXISTS student (rno INT PRIMARY KEY, name VARCHAR(20), branch VARCHAR(10), marks DOUBLE)";
            st.execute(createTable);
            System.out.println("Student table ready.");

            System.out.print("Enter Roll No, Name, Branch, Marks: ");
            int rno = sc.nextInt();
            String name = sc.next();
            String branch = sc.next();
            double marks = sc.nextDouble();

            String insert = "INSERT INTO student VALUES (?, ?, ?, ?)";
            try (PreparedStatement pst = con.prepareStatement(insert)) {
                pst.setInt(1, rno);
                pst.setString(2, name);
                pst.setString(3, branch);
                pst.setDouble(4, marks);
                System.out.println(pst.executeUpdate() + " record inserted.");
            }
        } catch (Exception e) {
            System.out.println("Database Error: " + e.getMessage());
        }
    }
}