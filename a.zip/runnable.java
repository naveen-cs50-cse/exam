class Demo implements Runnable {
    Thread t;

    Demo(String name) {
        t = new Thread(this, name);
        t.start();
    }

    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(t.getName() + " : " + i);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        new Demo("Thread 1");
        new Demo("Thread 2");
        new Demo("Thread 3");
        
        for (int i = 1; i <= 5; i++) {
            System.out.println("Main Thread : " + i);
        }
    }
}