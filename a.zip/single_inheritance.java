class Account {
    protected String name;
    protected double bal;

    public Account(String name, double bal) {
        this.name = name;
        this.bal = bal;
        System.out.println("Account Constructor Called");
    }

    public void details() {
        System.out.println("Account Holder: " + name);
        System.out.println("Balance: " + bal);
    }
}

class SavingsAcc extends Account {
    private double interest;

    public SavingsAcc(String name, double bal, double interest) {
        super(name, bal);
        this.interest = interest;
        System.out.println("SavingsAccount Constructor Called");
    }

    public void savingDetails() {
        super.details();
        System.out.println("Interest Rate: " + interest + "%");
    }
}

public class Main {
    public static void main(String[] args) {
        SavingsAcc sa = new SavingsAcc("Sreenith", 3000000.0, 3.5);
        sa.savingDetails();
    }
}