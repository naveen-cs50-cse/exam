import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the file name: ");
        String fname = sc.nextLine();
        File f = new File(fname);

        if (f.exists()) {
            System.out.println("Found: " + fname);
            System.out.println("Location: " + f.getAbsolutePath());
            System.out.println("Readable: " + f.canRead());
            System.out.println("Writable: " + f.canWrite());
            System.out.println("Length (bytes): " + f.length());

            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String line;
                System.out.println("\n--- File Contents ---");
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
            } catch (Exception e) {
                System.out.println("Error reading file: " + e.getMessage());
            }
        } else {
            System.out.println("File not found!");
        }
    }
}