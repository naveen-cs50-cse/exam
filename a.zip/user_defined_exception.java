import java.util.Scanner;

class AgeException extends Exception {
    AgeException(String desc) {
        super(desc);
    }
}

public class UserExc {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter age: ");
            int age = sc.nextInt();
            
            if (age < 18) {
                throw new AgeException("Invalid age for Vaccination");
            }
            
            System.out.println("You are eligible for COVID vaccination");
            System.out.println("Vaccination Given");
        } catch (AgeException e) {
            System.out.println(e.getMessage());
        }
    }
}