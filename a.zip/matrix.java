import java.util.Scanner;

public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Rows and cols of matrix A:");
        int r1 = sc.nextInt(), c1 = sc.nextInt();
        int[][] a = new int[r1][c1];
        for (int i = 0; i < r1; i++) 
            for (int j = 0; j < c1; j++) a[i][j] = sc.nextInt();

        System.out.println("Rows and cols of matrix B:");
        int r2 = sc.nextInt(), c2 = sc.nextInt();
        if (c1 != r2) {
            System.out.println("Incompatible dimensions.");
            return;
        }
        int[][] b = new int[r2][c2];
        for (int i = 0; i < r2; i++) 
            for (int j = 0; j < c2; j++) b[i][j] = sc.nextInt();

        System.out.println("Resultant Matrix:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c2; j++) {
                int sum = 0;
                for (int k = 0; k < c1; k++) sum += a[i][k] * b[k][j];
                System.out.print(sum + " ");
            }
            System.out.println();
        }
    }
}