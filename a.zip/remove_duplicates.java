import java.util.*;

public class Main {
    public static List<Integer> removeDup(List<Integer> num) {
        Set<Integer> uniqNum = new HashSet<>(num);
        return new ArrayList<>(uniqNum);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();
        
        List<Integer> num = new ArrayList<>();
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            num.add(sc.nextInt());
        }
        
        System.out.println("Original list: " + num);
        List<Integer> noDup = removeDup(num);
        System.out.println("List without duplicates: " + noDup);
        
        sc.close();
    }
}