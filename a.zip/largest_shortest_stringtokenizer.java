import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuilder text = new StringBuilder();
        
        System.out.println("Enter text (type 'exit' on a new line to finish):");
        while (true) {
            String line = sc.nextLine();
            if (line.equalsIgnoreCase("exit")) break;
            text.append(line).append(" ");
        }
        
        StringTokenizer t = new StringTokenizer(text.toString());
        String longest = "";
        String shortest = null;
        
        while (t.hasMoreTokens()) {
            String curr = t.nextToken();
            if (curr.length() > longest.length()) {
                longest = curr;
            }
            if (shortest == null || curr.length() < shortest.length()) {
                shortest = curr;
            }
        }
        
        if (longest.isEmpty() || shortest == null) {
            System.out.println("No words found.");
        } else {
            System.out.println("\nLongest word: " + longest);
            System.out.println("Shortest word: " + shortest);
        }
        
        sc.close();
    }
}