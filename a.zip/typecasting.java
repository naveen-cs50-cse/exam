public class TypeCasting {
    public static void main(String[] args) {
        System.out.println("Implicit type casting:");
        int a = 10;
        float b = 20f;
        float c = a + b;
        System.out.println("Answer = " + c);

        System.out.println("\nExplicit Type casting:");
        float x = 35f;
        float z = 100f;
        float y = x + z;
        System.out.println("Integer cast: " + (int)y);
        System.out.println("Double cast: " + (double)y);
    }
}