class Emp {
    String name;
    int id;

    Emp(String name, int id) {
        this.name = name;
        this.id = id;
    }

    void displayDetails() {
        System.out.println("ID: " + id + ", Name: " + name);
    }
}

class PEmp extends Emp {
    int hoursWorked;

    PEmp(String name, int id, int hoursWorked) {
        super(name, id);
        this.hoursWorked = hoursWorked;
    }

    void displayDetails() {
        super.displayDetails();
        System.out.println("Part-Time, Hours Worked: " + hoursWorked);
    }
}

class FEmp extends Emp {
    double salary;

    FEmp(String name, int id, double salary) {
        super(name, id);
        this.salary = salary;
    }

    void displayDetails() {
        super.displayDetails();
        System.out.println("Full-Time, Salary: " + salary);
    }
}

public class Main {
    public static void main(String[] args) {
        PEmp partTimeEmp = new PEmp("Alice", 101, 20);
        FEmp fullTimeEmp = new FEmp("Bob", 102, 50000);
        
        partTimeEmp.displayDetails();
        fullTimeEmp.displayDetails();
    }
}