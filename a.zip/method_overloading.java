class MethodOverload {
    void add(int a, int b) {
        System.out.println("The sum of two numbers is: " + (a + b));
    }

    void add(int[] a, int[] b) {
        int[] c = new int[a.length];
        System.out.println("The sum of arrays are:");
        for (int i = 0; i < a.length; i++) {
            c[i] = a[i] + b[i];
            System.out.print(c[i] + " ");
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        MethodOverload x = new MethodOverload();
        x.add(40, 60);
        x.add(new int[]{111, 222, 333}, new int[]{444, 555, 666});
    }
}