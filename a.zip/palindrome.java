import java.util.Deque;
import java.util.LinkedList;

public class Main {
    public static boolean isPalindrome(String str) {
        if (str == null) return false;
        
        Deque<Character> deque = new LinkedList<>();
        str = str.toLowerCase().replaceAll("[^a-z0-9]", "");
        
        for (char ch : str.toCharArray()) {
            deque.addLast(ch);
        }
        
        while (deque.size() > 1) {
            if (deque.removeFirst() != deque.removeLast()) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        String test = "Malayalam";
        if (isPalindrome(test)) {
            System.out.println("\"" + test + "\" is a palindrome.");
        } else {
            System.out.println("\"" + test + "\" is not a palindrome.");
        }
    }
}