class Stu {
    String name;
    int id;
    double grade;

    public Stu(String name, int id, double grade) {
        this.name = name;
        this.id = id;
        this.grade = grade;
    }

    void disp() {
        System.out.printf("%s\t %d\t %.2f\n", name, id, grade); 
    }
}

public class Main {
    public static void main(String[] args) {
        Stu[] s = {
            new Stu("Prabhas", 101, 85.6),
            new Stu("NTR", 102, 90.4),
            new Stu("Arjun", 103, 78.2),
            new Stu("Mahesh", 104, 92.1),
            new Stu("Ravi", 105, 88.5)
        };

        System.out.println("Student Report\n");
        System.out.printf("%s\t %s\t %s\n", "Name", "ID", "Grade"); 
        
        for (Stu student : s) {
            student.disp();
        }
    }
}