import java.util.Stack;
import java.util.Scanner;

public class Main {
    public static void sort(Stack<Integer> s) {
        Stack<Integer> temp = new Stack<>();
        while (!s.isEmpty()) {
            int curr = s.pop();
            while (!temp.isEmpty() && temp.peek() > curr) {
                s.push(temp.pop());
            }
            temp.push(curr);
        }
        while (!temp.isEmpty()) {
            s.push(temp.pop());
        }
    }

    public static void print(Stack<Integer> s) {
        Stack<Integer> temp = new Stack<>();
        while (!s.isEmpty()) {
            int value = s.pop();
            System.out.print(value + " ");
            temp.push(value);
        }
        System.out.println();
        while (!temp.isEmpty()) {
            s.push(temp.pop());
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of elements: ");
        int n = sc.nextInt();
        Stack<Integer> s = new Stack<>();

        System.out.println("Enter elements:");
        for (int i = 0; i < n; i++) {
            s.push(sc.nextInt());
        }

        System.out.println("Original Stack:");
        print(s);
        sort(s);
        System.out.println("Sorted Stack:");
        print(s);
    }
}