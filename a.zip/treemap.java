import java.util.*;

public class Main {
    public static void main(String[] args) {
        TreeMap<Integer, String> stu = new TreeMap<>();
        
        stu.put(3, "Aarav");
        stu.put(1, "Isha");
        stu.put(5, "Rohan");
        stu.put(2, "Ananya");
        stu.put(4, "Vihaan");
        
        System.out.println("Sorted Student Data:");
        for (Map.Entry<Integer, String> entry : stu.entrySet()) {
            System.out.println("Roll No: " + entry.getKey() + ", Name: " + entry.getValue());
        }
        
        Map.Entry<Integer, String> first = stu.firstEntry();
        System.out.println("\nFirst Student: Roll No " + first.getKey() + ", Name: " + first.getValue());
        
        Map.Entry<Integer, String> last = stu.lastEntry();
        System.out.println("Last Student: Roll No " + last.getKey() + ", Name: " + last.getValue());
    }
}