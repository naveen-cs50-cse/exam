package bnk;
import java.time.Year;

public class Operations {
    double roi;
    int year;

    public Operations() {
        roi = 7.5;
        year = Year.now().getValue();
    }

    public int getAge(int x) {
        return year - x;
    }

    public double getSimpleIntr(double amt, int t) {
        return (amt * t * roi) / 100;
    }
}


import bnk.Operations;
import java.util.Scanner;

public class BankTest {
    public static void main(String[] args) {
        Operations x = new Operations();
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter birth year: ");
        int yr = sc.nextInt();
        System.out.println("Age = " + x.getAge(yr));
        
        System.out.print("Enter Amount: ");
        double amt = sc.nextDouble();
        System.out.print("Enter Time period (in years): ");
        int t = sc.nextInt();
        
        System.out.println("Simple interest = " + x.getSimpleIntr(amt, t));
    }
}