class Thr1 extends Thread {
    int[] a;

    Thr1(int[] x) {
        a = x;
    }

    public void run() {
        for (int i = 0; i < a.length; i++) {
            System.out.println("Square of " + a[i] + " is: " + (a[i] * a[i]));
            try { Thread.sleep(10); } catch (Exception e) {}
        }
    }
}

class Thr2 extends Thread {
    String s;

    Thr2(String x) {
        s = x;
    }

    public void run() {
        for (int i = 0; i < s.length(); i++) {
            System.out.println("Char at " + i + " is: " + Character.toUpperCase(s.charAt(i)));
            try { Thread.sleep(10); } catch (Exception e) {}
        }
    }
}

public class MultiTask {
    public static void main(String[] args) {
        int[] x = {45, 66, 123, 456, 76};
        Thr1 t1 = new Thr1(x);
        
        String y = "Welcome";
        Thr2 t2 = new Thr2(y);
        
        t1.start();
        t2.start();
        
        System.out.println("Bye from main");
    }
}