public class Main {
    public static void main(String[] args) {
        String s = " Hi hello How are you";
        
        System.out.println("1. Length = " + s.length());
        System.out.println("2. Character at 7 = " + s.charAt(7));
        System.out.println("3. Substring = " + s.substring(7, 14));
        System.out.println("4. Upper case = " + s.toUpperCase());
        System.out.println("5. Lower case = " + s.toLowerCase());
        System.out.println("6. Replace = " + s.replace("Hi", "HI!"));
        System.out.println("7. Starts with = " + s.startsWith(" H"));
        System.out.println("8. Ends with = " + s.endsWith("u"));
        System.out.println("9. Is empty = " + s.isEmpty());
        System.out.println("10. Region matches = " + s.regionMatches(0, "H", 2, 5));
        System.out.println("11. Trim = " + s.trim());
        System.out.println("12. Contains = " + s.contains("h"));
        System.out.println("13. Index of = " + s.indexOf("h"));
        System.out.println("14. Last index of = " + s.lastIndexOf("i"));
        System.out.println("15. Last index for offset 4 = " + s.lastIndexOf("H", 4)); 
    } 
}