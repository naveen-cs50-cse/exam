class Resource {
    int data = -1;

    public synchronized void produce() throws InterruptedException {
        if (data != -1) {
            System.out.println("Producer is waiting...");
            wait();
        }
        data = 1000;
        System.out.println("Item Produced: " + data);
        notify();
    }

    public synchronized void consume() throws InterruptedException {
        if (data == -1) {
            System.out.println("Consumer is waiting...");
            wait();
        }
        System.out.println("Consumed data is: " + data + "\n");
        data = -1;
        notify();
    }
}

class Producer extends Thread {
    Resource r;
    Producer(Resource x) { r = x; }

    public void run() {
        try {
            for (int i = 0; i < 5; i++) r.produce();
        } catch (InterruptedException e) { e.printStackTrace(); }
    }
}

class Consumer extends Thread {
    Resource r;
    Consumer(Resource x) { r = x; }

    public void run() {
        try {
            for (int i = 0; i < 5; i++) r.consume();
        } catch (InterruptedException e) { e.printStackTrace(); }
    }
}

public class Main {
    public static void main(String[] args) {
        Resource s = new Resource();
        Producer p = new Producer(s);
        Consumer c = new Consumer(s);
        
        p.start();
        c.start();
    }
}