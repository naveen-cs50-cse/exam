import java.io.*;

public class Main {
    public static void main(String[] args) {
        int c = 0, w = 0, l = 0, ch;
        String f = "Sample.txt";

        try (FileReader fr = new FileReader(f)) {
            int x = f.indexOf(".");
            String ft = f.substring(x + 1);
            System.out.println("File Type is : " + ft);

            while ((ch = fr.read()) != -1) {
                c++;
                if ((char) ch == ' ' || (char) ch == '\t') {
                    w++;
                }
                if ((char) ch == '\n') {
                    l++;
                    w++; 
                }
            }
            
            if (c > 0) {
                w++; 
                l++; 
            }

            System.out.println("No of Characters : " + c);
            System.out.println("No of Words: " + w);
            System.out.println("No of Lines: " + l);

        } catch (Exception e) {
            System.out.println("File not found or error reading: " + e.getMessage());
        }
    }
}