import java.util.*;

class Product {
    int pid;
    String pname;

    public Product(int pid, String pname) {
        this.pid = pid;
        this.pname = pname;
    }

    @Override
    public String toString() {
        return "Product ID=" + pid + ", Name=" + pname;
    }
}

public class Main {
    private LinkedList<Product> productList = new LinkedList<>();
    private Scanner sc = new Scanner(System.in);

    public void addProduct() {
        System.out.print("Enter ID and Name: ");
        productList.add(new Product(sc.nextInt(), sc.next()));
        System.out.println("Product added.");
    }

    public void searchProduct() {
        System.out.print("Enter ID to search: ");
        int pid = sc.nextInt();
        for (Product p : productList) {
            if (p.pid == pid) {
                System.out.println("Found: " + p);
                return;
            }
        }
        System.out.println("Product not found!");
    }

    public void updateProduct() {
        System.out.print("Enter ID to update: ");
        int pid = sc.nextInt();
        for (Product p : productList) {
            if (p.pid == pid) {
                System.out.print("Enter new name: ");
                p.pname = sc.next();
                System.out.println("Product updated.");
                return;
            }
        }
        System.out.println("Product not found.");
    }

    public void deleteProduct() {
        System.out.print("Enter ID to delete: ");
        int pid = sc.nextInt();
        if (productList.removeIf(p -> p.pid == pid)) {
            System.out.println("Product deleted.");
        } else {
            System.out.println("Product not found.");
        }
    }

    public void displayProducts() {
        if (productList.isEmpty()) System.out.println("No products available.");
        else productList.forEach(System.out::println);
    }

    public static void main(String[] args) {
        Main system = new Main();
        int choice;
        do {
            System.out.println("\n1.Add 2.Search 3.Update 4.Delete 5.Display 6.Exit");
            System.out.print("Choice: ");
            choice = system.sc.nextInt();
            switch (choice) {
                case 1 -> system.addProduct();
                case 2 -> system.searchProduct();
                case 3 -> system.updateProduct();
                case 4 -> system.deleteProduct();
                case 5 -> system.displayProducts();
                case 6 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 6);
    }
}