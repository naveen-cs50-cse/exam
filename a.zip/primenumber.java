import java.util.Scanner;

public class PrimeNumbersInRange {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter lower and upper bounds: ");
        int x = sc.nextInt(), y = sc.nextInt();
        System.out.println("Prime numbers:");
        for (int num = x; num <= y; num++) {
            boolean isPrime = num > 1;
            for (int i = 2; i <= num / 2; i++) {
                if (num % i == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) System.out.println(num);
        }
    }
}