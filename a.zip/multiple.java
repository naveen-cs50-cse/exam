interface Arr {
    void print();
}

interface MyStack {
    void push(int x);
    int pop();
}

class StackArr implements Arr, MyStack {
    int[] st;
    int n, top;

    StackArr() {
        n = 5;
        top = -1;
        st = new int[n];
    }

    public void push(int x) {
        if (top == n - 1) {
            System.out.println("Stack Full");
        } else {
            st[++top] = x;
        }
    }

    public int pop() {
        if (top == -1) return -1;
        return st[top--];
    }

    public void print() {
        System.out.print("[");
        for (int i = 0; i <= top; i++) {
            System.out.print(st[i] + " ");
        }
        System.out.println("]");
    }
}

public class Main {
    public static void main(String[] args) {
        StackArr ob = new StackArr();
        System.out.print("Empty stack: ");
        ob.print();
        
        ob.push(556);
        ob.push(787);
        ob.push(303);
        System.out.println("After push operations:");
        ob.print();
        
        System.out.println("Popped element = " + ob.pop());
        System.out.println("After pop operation:");
        ob.print();
    }
}