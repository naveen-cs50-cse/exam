import java.util.*;

public class Main {
    public static void main(String[] args) {
        HashMap<String, String> cMap = new HashMap<>();
        Scanner sc = new Scanner(System.in);
        
        cMap.put("India", "New Delhi");
        cMap.put("Japan", "Tokyo");
        cMap.put("USA", "Washington DC");
        cMap.put("France", "Paris");
        cMap.put("China", "Beijing");
        
        System.out.println("Countries and Capitals:");
        for (String c : cMap.keySet()) {
            System.out.println(c + " - " + cMap.get(c));
        }
        
        System.out.print("\nEnter Country to Search: ");
        String search = sc.nextLine();
        if (cMap.containsKey(search)) {
            System.out.println("Capital of " + search + ": " + cMap.get(search));
        } else {
            System.out.println("Country not found.");
        }
        
        System.out.print("\nEnter Country to Delete: ");
        String delete = sc.nextLine();
        if (cMap.containsKey(delete)) {
            cMap.remove(delete);
            System.out.println(delete + " deleted.");
        } else {
            System.out.println("Country not found.");
        }
        
        System.out.println("\nRemaining Data:");
        for (String c : cMap.keySet()) {
            System.out.println(c + " - " + cMap.get(c));
        }
    }
}