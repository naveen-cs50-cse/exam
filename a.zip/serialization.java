import java.io.*;

class Person implements Serializable {
    String name;
    int age;
    long mobno;

    Person(String name, int age, long mobno) {
        this.name = name;
        this.age = age;
        this.mobno = mobno;
    }
}

public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("Mahesh Babu", 20, 123);
        Person p2 = new Person("Pawan Kalyan", 23, 456);

        try (FileOutputStream fos = new FileOutputStream("Serialize.txt");
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(p1);
            oos.writeObject(p2);
            System.out.println("Person objects serialized");
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println("Performing Deserialization:");
        try (FileInputStream fis = new FileInputStream("Serialize.txt");
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            Person t1 = (Person) ois.readObject();
            Person t2 = (Person) ois.readObject();

            System.out.println("Person 1 - Name: " + t1.name + ", Age: " + t1.age);
            System.out.println("Person 2 - Name: " + t2.name + ", Age: " + t2.age);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}