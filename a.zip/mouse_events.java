import java.awt.*;
import java.awt.event.*;

public class MouseEvents extends Frame implements MouseListener, MouseMotionListener {
    Label st = new Label("                                 ");
    
    public MouseEvents() {
        setLayout(new FlowLayout());
        add(st);
        addMouseListener(this);
        addMouseMotionListener(this);
        setSize(400, 400);
        setVisible(true);
    }
    
    public void mouseClicked(MouseEvent me) { st.setText("Mouse Clicked"); }
    public void mouseEntered(MouseEvent me) { st.setText("Mouse Entered"); }
    public void mouseExited(MouseEvent me) { st.setText("Mouse Exited"); }
    public void mousePressed(MouseEvent me) { st.setText("Mouse Down"); }
    public void mouseReleased(MouseEvent me) { st.setText("Mouse Up"); }
    public void mouseDragged(MouseEvent me) { st.setText("Dragging at " + me.getX() + "," + me.getY()); }
    public void mouseMoved(MouseEvent me) { st.setText("Moving at " + me.getX() + "," + me.getY()); }

    public static void main(String[] args) { new MouseEvents(); }
}