import java.util.Scanner;

class GroupOper {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements:");
        int n = sc.nextInt();
        int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE, sum = 0;
        
        for (int i = 0; i < n; i++) {
            int a = sc.nextInt();
            if (a < min) min = a;
            if (a > max) max = a;
            sum += a;
        }
        System.out.println("MAX: " + max + "\nMIN: " + min + "\nSUM: " + sum + "\nAVG: " + (sum / n));
    }
}