import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter 2 numbers:");
        int a = sc.nextInt();
        int b = sc.nextInt();
        
        System.out.println("a & b = " + (a & b));
        System.out.println("a | b = " + (a | b));
        System.out.println("a ^ b = " + (a ^ b));
        System.out.println("~a = " + (~a));

        System.out.println("\nEnter shift positions for 'a':");
        int shift = sc.nextInt();
        
        System.out.println("a << " + shift + " = " + (a << shift));
        System.out.println("a >> " + shift + " = " + (a >> shift));
        System.out.println("a >>> " + shift + " = " + (a >>> shift));
        
        sc.close();
    }
}