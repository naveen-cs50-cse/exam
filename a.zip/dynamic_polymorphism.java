import java.util.Scanner;

class Animal {
    void disp() {
        System.out.println("Animal makes a sound");
    }
}

class Dog extends Animal {
    void disp() {
        System.out.println("Bark!");
    }
}

class Cat extends Animal {
    void disp() {
        System.out.println("Meow!");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Animal a;
        
        System.out.println("Dog(1) or Cat(2)?\nEnter 1 or 2:");
        int ch = sc.nextInt();
        
        if (ch == 1) {
            a = new Dog();
        } else if (ch == 2) {
            a = new Cat();
        } else {
            a = new Animal();
        }
        
        a.disp();
    }
}