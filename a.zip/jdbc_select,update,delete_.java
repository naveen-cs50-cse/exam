import java.sql.*;
import java.util.Scanner;

public class StudentJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/test";
        String user = "root", pass = "";

        try (Connection con = DriverManager.getConnection(url, user, pass);
             Scanner sc = new Scanner(System.in)) {
             
            System.out.println("1.Select 2.Update 3.Delete");
            System.out.print("Choice: ");
            int ch = sc.nextInt();
            
            if (ch == 1) {
                System.out.print("Enter ID to fetch: ");
                PreparedStatement ps = con.prepareStatement("SELECT * FROM student WHERE rno = ?");
                ps.setInt(1, sc.nextInt());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) System.out.println("Found: " + rs.getInt("rno") + " - " + rs.getString("name"));
                else System.out.println("Student not found.");
            } 
            else if (ch == 2) {
                System.out.print("Enter ID to update and new Name: ");
                int id = sc.nextInt();
                String name = sc.next();
                PreparedStatement ps = con.prepareStatement("UPDATE student SET name=? WHERE rno=?");
                ps.setString(1, name); 
                ps.setInt(2, id);
                System.out.println(ps.executeUpdate() > 0 ? "Updated successfully" : "Student not found");
            } 
            else if (ch == 3) {
                System.out.print("Enter ID to delete: ");
                PreparedStatement ps = con.prepareStatement("DELETE FROM student WHERE rno=?");
                ps.setInt(1, sc.nextInt());
                System.out.println(ps.executeUpdate() > 0 ? "Deleted successfully" : "Student not found");
            } else {
                System.out.println("Invalid Choice.");
            }
        } catch (Exception e) {
            System.out.println("Database Error: " + e.getMessage());
        }
    }
}