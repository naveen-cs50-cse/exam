public class ExceptionDemo {
    public static void main(String[] args) {
        int[] a = {1, 2, 3};
        int c = 20, d = 0, x;

        try {
            int sum = a[0] + a[1] + a[2] + a[3]; 
            System.out.println("The array sum is: " + sum);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index exceeded");
            System.out.println(e);
        }

        System.out.println("--- Another try-catch block ---");

        try {
            x = c / d; 
            System.out.println(x);
        } catch (ArithmeticException e) {
            System.out.println("Division problem");
            System.out.println(e);
        }

        System.out.println("After catch block");
    }
}