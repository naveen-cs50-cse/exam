class SampleThread implements Runnable
{
    public void run()
    {
        System.out.println("Thread is under Running...");
        for(int i= 1; i<=10; i++)
            {
                System.out.println("i = " + i);
            }
    
    }
}
public class RunableDemo
{
    public static void main(String[] args)
    {
        SampleThread threadObj= new SampleThread();
        Thread t= new Thread(threadObj);
        System.out.println("Thread about to start...");
        t.start();
    }
}