import java.util.*;

public class StringTokenizerDemo {
    public static void main(String[] args) {
        StringTokenizer st = new StringTokenizer("Java is easy");
        while (st.hasMoreTokens())
            System.out.println(st.nextToken());

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number:");
        int n = sc.nextInt();

        Date d = new Date();
        System.out.println("Date: " + d);
    }
}
