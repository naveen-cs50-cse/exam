import java.util.*;

public class CollectionDemo {
    public static void main(String[] args) {
        ArrayList<String> al = new ArrayList<>();
        al.add("A");
        al.add("B");

        LinkedList<String> ll = new LinkedList<>();
        ll.add("X");
        ll.add("Y");

        HashMap<Integer,String> hm = new HashMap<>();
        hm.put(1,"One");

        TreeMap<Integer,String> tm = new TreeMap<>();
        tm.put(2,"Two");

        System.out.println(al);
        System.out.println(ll);
        System.out.println(hm);
        System.out.println(tm);
    }
}
