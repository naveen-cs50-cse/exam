import java.awt.*; 
import java.awt.event.*; 
public class AWTDemo extends Frame implements ActionListener, TextListener, ItemListener { 
    Label l; 
    TextField tf; 
    TextArea ta; 
    Button b; 
    Checkbox cb1,cb2; 
    Canvas c; 
    public AWTDemo() { 
        setTitle("Welcome to my AWT frame"); 
        setSize(450, 450); 
        setLayout(new FlowLayout()); 
        setBackground(Color.lightGray); 

        l = new Label("Enter your name:"); 
        add(l); 
         
        tf = new TextField(20); 
        tf.addTextListener(this); 
        add(tf); 
         
        b = new Button("Submit"); 
        b.addActionListener(this); 
        add(b); 
         
        ta = new TextArea("Hello", 5, 25); 
        add(ta); 
       
        cb1 = new Checkbox("Java"); 
        cb2=new Checkbox("python"); 
        cb1.addItemListener(this); 
        cb2.addItemListener(this); 
        add(cb1); 
        add(cb2); 
        
        c = new Canvas() { 
            public void paint(Graphics g) { 
                g.setColor(Color.blue); 
                g.fillRect(10, 10, 50, 50); 
            } 
        }; 
        c.setSize(70, 70); 
        c.setBackground(Color.white); 
        add(c); 
        
        addWindowListener(new WindowAdapter() { 
            public void windowClosing(WindowEvent we) { 
                System.exit(0); 
            } 
        }); 
  setVisible(true); 
    } 
    
    public void actionPerformed(ActionEvent ae) { 
        ta.setText("Hello, " + tf.getText() + "!"); 
    } 
     
    public void textValueChanged(TextEvent te) { 
        ta.setText("Typing: " + tf.getText()); 
    } 
  
public void itemStateChanged(ItemEvent ie) { 
ta.setText("Java: " + cb1.getState() + ", Python: " + cb2.getState()); 
} 
    public static void main(String[] args) { 
        new AWTDemo(); 
    } 
}