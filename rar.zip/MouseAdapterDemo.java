import java.awt.*;
import java.awt.event.*;
public class MouseAdapterDemo extends Frame {
    Label l;
    public MouseAdapterDemo() {
        l = new Label("Click anywhere inside the window");
        l.setFont(new Font("Arial", Font.BOLD, 20));
        add(l);
        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                l.setText("Mouse clicked at X=" + e.getX() + ", Y=" + e.getY());
            }
        });
        setSize(500, 300);
        setLayout(new FlowLayout());
        setVisible(true);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
            System.exit(0);
        }
    });
}
public static void main(String[] args) {
    new MouseAdapterDemo();
}
}