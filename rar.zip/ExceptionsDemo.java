 import java.io.*;
 import java.util.Scanner;
 public class ExceptionsDemo {
    public static void main(String[] args) {    
        // 1. ArithmeticException
        try {
            int a = 10;
            int b = 0;
            int result = a / b; 
            System.out.println(result);
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException: Cannot divide by zero!");
        }
        // 2. NullPointerException
        try {
            String str = null;
            System.out.println(str.length()); 
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: String is null!");
        }
        // 3. FileNotFoundException
        try {
            File file = new File("nonexistentfile.txt");
            Scanner sc = new Scanner(file); 
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFoundException: File not found!");
        }
        // 4. ArrayIndexOutOfBoundsException
        try {
            int[] numbers = {1, 2, 3};
            System.out.println(numbers[5]); 
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException: Invalid array index!");
        }
 // 5.  NumberFormatException
        try {
            String str = "abc"; 
            int num = Integer.parseInt(str);
            System.out.println(num);
        } catch (NumberFormatException e) {
 System.out.println("NumberFormatException: Cannot convert \"" + "abc" + "\" to a number!");  
}
 }
}