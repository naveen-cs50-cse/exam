class SharedBuffer {
    int n;
    boolean produce = false;
    public synchronized void produce(int x) {
        try {
            while (produce) {
                wait();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        n = x;
        System.out.println("Producer produced:" + x);
        produce = true;
        notify();
    }
    public synchronized int consume() {
        try {
            while (!produce) {
                wait();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("Consumer consumed: " + n);
        produce = false;
        notify();
        return n;
    }
}
class Producer extends Thread {
    SharedBuffer b;
    Producer(SharedBuffer b) {
        this.b = b;
    }
    public void run() {
        for (int i = 1; i<= 5; i++) {
            b.produce(i);
        }
    }
}
class Consumer extends Thread {
    SharedBuffer b;
    Consumer(SharedBuffer b) {
        this.b = b;
    }
    public void run() {
        for (int i = 1; i<= 5; i++) {
            b.consume();
        }
    }
}
public class ProducerConsumerDemo {
    public static void main(String[] args) {
        SharedBuffer b = new SharedBuffer();
        Producer p = new Producer(b);
        Consumer c = new Consumer(b);
        p.start();
        c.start();
    }
}