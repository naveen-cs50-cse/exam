import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;
public class ByteStreamDemo {
    public static void main(String[] args) {
        try {
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter file name:");
            String fname=sc.nextLine();
            FileOutputStream fos=new FileOutputStream(fname);
            System.out.println("File has created..Enter some data:");
            String data=sc.nextLine();
            fos.write(data.getBytes());
            System.out.println("Data written to file");
            fos.close();
            FileInputStream fis=new FileInputStream(fname);
            int i;
            while((i=fis.read())!=-1)
                System.out.print((char)i);
            fis.close();

        } catch (Exception e) {
            System.out.println("Error="+e);

        }
    }
}