#include <stdio.h>

int a[100], n;

void adjust(int i, int n)
{
    int j, temp;

    j = 2 * i + 1;

    while (j < n)
    {
        if (j < n - 1)
        {
            if (a[j] < a[j + 1])
                j++;
        }

        if (a[i] < a[j])
        {
            temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }
        else
            break;

        i = j;
        j = 2 * i + 1;
    }
}

void main()
{
    int i, temp;

    printf("Enter size of array\n");
    scanf("%d", &n);

    printf("Enter array elements\n");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = n / 2 - 1; i >= 0; i--)
        adjust(i, n);

    printf("Max heap elements are...\n");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);

    printf("\n");

    for (i = n - 1; i >= 1; i--)
    {
        temp = a[0];
        a[0] = a[i];
        a[i] = temp;

        adjust(0, i);
    }

    printf("Heap sort elements are...\n");
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
}
