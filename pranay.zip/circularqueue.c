#include <stdio.h>
#include <stdlib.h>

int cqueue[100];
int size;
int front = -1, rear = -1;

/* Enqueue operation */
void enqueue(int ele)
{
    if ((rear + 1) % size == front)
    {
        printf("Queue is full\n");
        return;
    }

    if (front == -1)   // first insertion
        front = 0;

    rear = (rear + 1) % size;
    cqueue[rear] = ele;
    printf("Inserted %d\n", ele);
}

/* Dequeue operation */
void dequeue()
{
    if (front == -1)
    {
        printf("Queue is empty\n");
        return;
    }

    printf("Deleted element is %d\n", cqueue[front]);

    if (front == rear)   // only one element
        front = rear = -1;
    else
        front = (front + 1) % size;
}

/* Display queue */
void display()
{
    int i;

    if (front == -1)
    {
        printf("Queue is empty\n");
        return;
    }

    printf("Queue elements are: ");
    i = front;

    while (1)
    {
        printf("%d ", cqueue[i]);
        if (i == rear)
            break;
        i = (i + 1) % size;
    }
    printf("\n");
}

/* Front element */
void frontElement()
{
    if (front == -1)
        printf("Queue is empty\n");
    else
        printf("Front element is %d\n", cqueue[front]);
}

/* Rear element */
void rearElement()
{
    if (rear == -1)
        printf("Queue is empty\n");
    else
        printf("Rear element is %d\n", cqueue[rear]);
}

int main()
{
    int choice, element;

    printf("Enter size of queue: ");
    scanf("%d", &size);

    if (size <= 0 || size > 100)
    {
        printf("Invalid size\n");
        return 1;
    }

    while (1)
    {
        printf("\n--- CIRCULAR QUEUE MENU ---\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Display\n");
        printf("4. Front Element\n");
        printf("5. Rear Element\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Enter element to insert: ");
                scanf("%d", &element);
                enqueue(element);
                break;

            case 2:
                dequeue();
                break;

            case 3:
                display();
                break;

            case 4:
                frontElement();
                break;

            case 5:
                rearElement();
                break;

            case 6:
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }

    return 0;
}
