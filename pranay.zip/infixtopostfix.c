#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 30
char stack[MAX];
int top = -1;

void push(char x);
char pop();
int isempty();
int priority(char ch);
void infixtopostfix(char *exp);

int main()
{
    char exp[20];
    printf("Enter proper infix expression: ");
    scanf("%s", exp);

    infixtopostfix(exp);
    return 0;
}

void push(char x)
{
    if (top != MAX - 1)
    {
        top++;
        stack[top] = x;
    }
}

char pop()
{
    if (top != -1)
    {
        char x = stack[top];
        top--;
        return x;
    }
    return '\0';
}

int isempty()
{
    return (top == -1);
}

int priority(char ch)
{
    switch (ch)
    {
    case '$':
        return 3;
    case '*':
    case '/':
    case '%':
        return 2;
    case '+':
    case '-':
        return 1;
    default:
        return 0;
    }
}

void infixtopostfix(char *a)
{
    int j = 0;
    char b[20];
    int len = strlen(a);

    for (int i = 0; i < len; i++)
    {
        char ch = a[i];

        if (isalnum(ch))
        {
            b[j++] = ch;
        }
        else if (ch == '(')
        {
            push(ch);
        }
        else if (ch == ')')
        {
            while (!isempty() && stack[top] != '(')
                b[j++] = pop();
            if (!isempty())
                pop(); // pop '('
        }
        else
        {
            while (!isempty() && priority(ch) <= priority(stack[top]))
                b[j++] = pop();
            push(ch);
        }
    }

    while (!isempty())
        b[j++] = pop();

    b[j] = '\0';
    printf("Postfix expression is: %s\n", b);
}
