#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *left;
    struct node *right;
};

/* Create a new node */
struct node* newnode(int ele)
{
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->data = ele;
    temp->left = NULL;
    temp->right = NULL;
    return temp;
}

/* Inorder Traversal */
void inorder(struct node* root)
{
    if (root == NULL)
        return;

    inorder(root->left);
    printf("%d ", root->data);
    inorder(root->right);
}

/* Preorder Traversal */
void preorder(struct node* root)
{
    if (root == NULL)
        return;

    printf("%d ", root->data);
    preorder(root->left);
    preorder(root->right);
}

/* Postorder Traversal */
void postorder(struct node* root)
{
    if (root == NULL)
        return;

    postorder(root->left);
    postorder(root->right);
    printf("%d ", root->data);
}

int main()
{
    struct node* root = newnode(10);

    root->left = newnode(20);
    root->right = newnode(30);

    root->left->left = newnode(40);
    root->left->right = newnode(50);

    root->right->left = newnode(60);
    root->right->right = newnode(70);

    printf("Inorder traversal: ");
    inorder(root);
    printf("\n");

    printf("Preorder traversal: ");
    preorder(root);
    printf("\n");

    printf("Postorder traversal: ");
    postorder(root);
    printf("\n");

    return 0;
}
