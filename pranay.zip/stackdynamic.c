#include <stdio.h>
#include <stdlib.h>

int *stack;
int size, top = -1;

int isempty() {
    return top == -1;
}

int isfull() {
    return top == size - 1;
}

void push(int e) {
    if (isfull()) {
        stack = (int*)realloc(stack, 2 * size * sizeof(int));
        if (!stack) {
            printf("Memory allocation failed\n");
            exit(1);
        }
        size = 2 * size;
        printf("Stack size increased to %d\n", size);
    }
    top++;
    stack[top] = e;
    printf("%d is pushed into the stack\n", e);
}

int pop() {
    if (isempty()) {
        return -1; // Indicates underflow
    }
    int x = stack[top];
    top--;
    return x;
}

void topelement() {
    if (isempty()) {
        printf("STACK IS EMPTY!\n");
    } else {
        printf("Top element is %d\n", stack[top]);
    }
}

void display() {
    if (isempty()) {
        printf("STACK IS EMPTY!\n");
        return;
    }
    printf("STACK ELEMENTS:\n");
    for (int i = top; i >= 0; i--) {
        printf("%d\n", stack[i]);
    }
}

int main() {
    int ch, x;
    printf("Enter initial size of the stack: ");
    scanf("%d", &size);

    stack = (int*)calloc(size, sizeof(int));
    if (!stack) {
        printf("Memory allocation failed\n");
        return 1;
    }

    do {
        printf("\n1. PUSH\n2. POP\n3. TOP ELEMENT\n4. DISPLAY\n5. EXIT\n");
        printf("Enter your choice: ");
        scanf("%d", &ch);

        switch (ch) {
            case 1:
                printf("Enter the element: ");
                scanf("%d", &x);
                push(x);
                break;
            case 2:
                x = pop();
                if (x == -1)
                    printf("STACK UNDERFLOW!\n");
                else
                    printf("Popped element is %d\n", x);
                break;
            case 3:
                topelement();
                break;
            case 4:
                display();
                break;
            case 5:
                printf("Exiting...\n");
                break;
            default:
                printf("INVALID INPUT!\n");
        }
    } while (ch != 5);

    free(stack);
    return 0;
}
