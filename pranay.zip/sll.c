#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

struct node *head = NULL;

void insert_begin() {
    struct node *ptr = (struct node*)malloc(sizeof(struct node));
    scanf("%d", &ptr->data);
    ptr->next = head;
    head = ptr;
}

void insert_end() {
    struct node *ptr = (struct node*)malloc(sizeof(struct node));
    struct node *temp = head;
    scanf("%d", &ptr->data);
    ptr->next = NULL;
    if (!head) head = ptr;
    else {
        while (temp->next) temp = temp->next;
        temp->next = ptr;
    }
}

void insert_pos() {
    int pos;
    struct node *ptr = (struct node*)malloc(sizeof(struct node));
    scanf("%d %d", &ptr->data, &pos);
    ptr->next = NULL;
    if (pos == 1) { ptr->next = head; head = ptr; return; }
    struct node *temp = head;
    for (int i = 1; i < pos-1 && temp; i++) temp = temp->next;
    if (!temp) { printf("Invalid position\n"); free(ptr); return; }
    ptr->next = temp->next;
    temp->next = ptr;
}

void del_begin() {
    if (!head) return;
    struct node *temp = head;
    head = head->next;
    free(temp);
}

void del_end() {
    if (!head) return;
    struct node *temp = head, *prev = NULL;
    if (!head->next) { free(head); head = NULL; return; }
    while (temp->next) { prev = temp; temp = temp->next; }
    prev->next = NULL;
    free(temp);
}

void delete_pos() {
    int pos;
    scanf("%d", &pos);
    if (!head) return;
    struct node *temp = head, *prev = NULL;
    if (pos == 1) { head = head->next; free(temp); return; }
    for (int i = 1; i < pos && temp; i++) { prev = temp; temp = temp->next; }
    if (!temp) return;
    prev->next = temp->next;
    free(temp);
}

void search() {
    int key, found = 0;
    scanf("%d", &key);
    struct node *temp = head;
    for (int i = 1; temp; i++) {
        if (temp->data == key) { printf("%d\n", i); found = 1; break; }
        temp = temp->next;
    }
    if (!found) printf("-1\n");
}

void reverse() {
    struct node *prev = NULL, *curr = head, *next;
    while (curr) { next = curr->next; curr->next = prev; prev = curr; curr = next; }
    head = prev;
}

void display() {
    struct node *temp = head;
    while (temp) { printf("%d ", temp->data); temp = temp->next; }
    printf("\n");
}

int main() {
    int choice;
    while (1) {
        printf("\nMenu:\n1. Insert Begin\n2. Insert End\n3. Insert Position\n4. Delete Begin\n5. Delete End\n6. Delete Position\n7. Search\n8. Reverse\n9. Display\n10. Exit\nEnter choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1: insert_begin(); break;
            case 2: insert_end(); break;
            case 3: insert_pos(); break;
            case 4: del_begin(); break;
            case 5: del_end(); break;
            case 6: delete_pos(); break;
            case 7: search(); break;
            case 8: reverse(); break;
            case 9: display(); break;
            case 10: exit(0);
            default: printf("Invalid choice\n");
        }
    }
}
