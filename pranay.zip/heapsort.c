#include <stdio.h>

int a[50], n;

void heap();
void adjust(int i, int n);

int main()
{
    int i;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("Before Sorting elements are:\n");
    for (i = 0; i < n; i++)
        printf("%d\t", a[i]);
    printf("\n");

    heap();

    printf("After Sorting elements are:\n");
    for (i = 0; i < n; i++)
        printf("%d\t", a[i]);
    printf("\n");

    return 0;
}

void heap()
{
    int i, temp;

    for (i = n / 2 - 1; i >= 0; i--)
        adjust(i, n);

    for (i = n - 1; i >= 1; i--)
    {
        temp = a[i];
        a[i] = a[0];
        a[0] = temp;

        adjust(0, i);
    }
}

void adjust(int i, int n)
{
    int j = 2 * i + 1;
    int temp = a[i];

    while (j <= n - 1)
    {
        if (j < n - 1 && a[j] < a[j + 1])
            j++;

        if (temp < a[j])
        {
            a[i] = a[j];
            i = j;
            j = 2 * i + 1;
        }
        else
            break;
    }
    a[i] = temp;
}
