#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *left, *right;
};

/* Create a new node */
struct node* createNode(int ele)
{
    struct node* newNode = (struct node*)malloc(sizeof(struct node));
    newNode->data = ele;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

/* Insert into BST */
struct node* insert(struct node* root, int ele)
{
    if (root == NULL)
        return createNode(ele);

    if (ele < root->data)
        root->left = insert(root->left, ele);
    else if (ele > root->data)
        root->right = insert(root->right, ele);

    return root;
}

/* Find minimum value node */
struct node* findMin(struct node* root)
{
    while (root->left != NULL)
        root = root->left;
    return root;
}

/* Delete a node */
struct node* deleteNode(struct node* root, int key)
{
    if (root == NULL)
        return root;

    if (key < root->data)
        root->left = deleteNode(root->left, key);
    else if (key > root->data)
        root->right = deleteNode(root->right, key);
    else
    {
        if (root->left == NULL)
        {
            struct node* temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            struct node* temp = root->left;
            free(root);
            return temp;
        }

        struct node* temp = findMin(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}

/* Search in BST */
struct node* search(struct node* root, int key)
{
    if (root == NULL || root->data == key)
        return root;

    if (key < root->data)
        return search(root->left, key);
    else
        return search(root->right, key);
}

/* Traversals */
void inorder(struct node* root)
{
    if (root != NULL)
    {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

void preorder(struct node* root)
{
    if (root != NULL)
    {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(struct node* root)
{
    if (root != NULL)
    {
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
}

/* Main Function */
int main()
{
    struct node* root = NULL;
    int ch, ele;

    while (1)
    {
        printf("\n--- Binary Search Tree Operations ---\n");
        printf("1. Insert\n");
        printf("2. Delete\n");
        printf("3. Search\n");
        printf("4. Inorder Traversal\n");
        printf("5. Preorder Traversal\n");
        printf("6. Postorder Traversal\n");
        printf("7. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &ch);

        switch (ch)
        {
            case 1:
                printf("Enter element to insert: ");
                scanf("%d", &ele);
                root = insert(root, ele);
                break;

            case 2:
                printf("Enter element to delete: ");
                scanf("%d", &ele);
                root = deleteNode(root, ele);
                break;

            case 3:
                printf("Enter element to search: ");
                scanf("%d", &ele);
                if (search(root, ele))
                    printf("Element found in BST\n");
                else
                    printf("Element not found in BST\n");
                break;

            case 4:
                printf("Inorder traversal: ");
                inorder(root);
                printf("\n");
                break;

            case 5:
                printf("Preorder traversal: ");
                preorder(root);
                printf("\n");
                break;

            case 6:
                printf("Postorder traversal: ");
                postorder(root);
                printf("\n");
                break;

            case 7:
                exit(0);

            default:
                printf("Invalid choice\n");
        }
    }

    return 0;
}
