#include <stdio.h>

int main()
{
    int a[100], n, i;
    int low, high, mid;
    int se, found = 0;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    if (n > 100 || n <= 0)
    {
        printf("Invalid number of elements.\n");
        return 1;
    }

    printf("Enter elements in ascending order:\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }

    printf("Enter search element: ");
    scanf("%d", &se);

    low = 0;
    high = n - 1;

    while (low <= high)
    {
        mid = low + (high - low) / 2;

        if (a[mid] == se)
        {
            printf("Element found at position %d (index %d)\n", mid + 1, mid);
            found = 1;
            break;
        }
        else if (se < a[mid])
        {
            high = mid - 1;
        }
        else
        {
            low = mid + 1;
        }
    }

    if (found == 0)
    {
        printf("Element not found.\n");
    }

    return 0;
}
