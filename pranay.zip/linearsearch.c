#include <stdio.h>

int main() {
    int a[50], size, i, key, found = 0;

    printf("Enter size of the array: ");
    scanf("%d", &size);

    printf("Enter %d elements of the array:\n", size);
    for (i = 0; i < size; i++) {
        scanf("%d", &a[i]);
    }

    printf("Enter key to search: ");
    scanf("%d", &key);

    for (i = 0; i < size; i++) {
        if (key == a[i]) {
            found = 1;
            printf("%d is found at a[%d]\n", key, i);
            break;
        }
    }

    if (!found) {
        printf("Element not found\n");
    }

    return 0;
}
