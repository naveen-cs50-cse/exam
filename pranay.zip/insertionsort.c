#include <stdio.h>

int main() {
    int size, i, j, temp;

    printf("Enter number of elements: ");
    scanf("%d", &size);

    int a[size];

    printf("Enter %d elements:\n", size);
    for (i = 0; i < size; i++) {
        scanf("%d", &a[i]);
    }

    // Insertion Sort
    for (i = 1; i < size; i++) {
        temp = a[i];
        j = i - 1;

        while (j >= 0 && a[j] > temp) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = temp;
    }

    printf("Sorted array:\n");
    for (i = 0; i < size; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    return 0;
}
