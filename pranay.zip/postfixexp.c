#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define MAX 30

int stack[MAX];
int top = -1;

void push(int x);
int pop();
int isempty();
void evaluate(char *exp);

int main()
{
    char p[20];
    printf("Enter a postfix expression with digits as operands:\n");
    scanf("%s", p);

    evaluate(p);
    return 0;
}

void push(int x)
{
    if (top != MAX - 1)
    {
        top++;
        stack[top] = x;
    }
    else
        printf("Stack overflow\n");
}

int pop()
{
    if (top != -1)
        return stack[top--];
    else
    {
        printf("Stack underflow\n");
        return 0;
    }
}

int isempty()
{
    return (top == -1);
}

void evaluate(char *a)
{
    int i;
    char ch;
    int op1, op2;

    for (i = 0; a[i] != '\0'; i++)
    {
        ch = a[i];

        if (isdigit(ch))
            push(ch - '0'); // Convert char digit to int
        else
        {
            op2 = pop();
            op1 = pop();

            switch (ch)
            {
            case '$':
                push(pow(op1, op2));
                break;
            case '*':
                push(op1 * op2);
                break;
            case '/':
                push(op1 / op2);
                break;
            case '%':
                push(op1 % op2);
                break;
            case '+':
                push(op1 + op2);
                break;
            case '-':
                push(op1 - op2);
                break;
            default:
                printf("Wrong input: %c\n", ch);
                return;
            }
        }
    }

    printf("Result = %d\n", pop());
}
