#include <stdio.h>
#include <stdlib.h>

int *ht, n, i, key, val, c, ch;

void insert();
void del();
void search();
void display();

/* Insert key into hash table */
void insert()
{
    printf("\nEnter key to insert: ");
    scanf("%d", &key);

    val = key % n;

    if (ht[val] == 0)
        ht[val] = key;
    else
    {
        for (i = (val + 1) % n; i != val; i = (i + 1) % n)
        {
            if (ht[i] == 0)
                break;
        }

        if (i != val)
            ht[i] = key;
        else
            printf("\nNo place to insert element");
    }
}

/* Search key in hash table */
void search()
{
    c = 0;
    printf("\nEnter key to search: ");
    scanf("%d", &key);

    val = key % n;

    if (ht[val] == key)
        printf("\nElement found at index %d", val);
    else
    {
        for (i = (val + 1) % n; i != val; i = (i + 1) % n)
        {
            if (ht[i] == key)
            {
                c = 1;
                break;
            }
        }

        if (c == 1)
            printf("\nElement found at index %d", i);
        else
            printf("\nElement not found");
    }
}

/* Delete key from hash table */
void del()
{
    c = 0;
    printf("\nEnter key to delete: ");
    scanf("%d", &key);

    val = key % n;

    if (ht[val] == key)
        ht[val] = 0;
    else
    {
        for (i = (val + 1) % n; i != val; i = (i + 1) % n)
        {
            if (ht[i] == key)
            {
                c = 1;
                break;
            }
        }

        if (c == 1)
            ht[i] = 0;
        else
            printf("\nElement not found");
    }
}

/* Display hash table */
void display()
{
    printf("\nHash Table (index -> value):\n");
    for (i = 0; i < n; i++)
        printf("%d\t%d\n", i, ht[i]);
}

int main()
{
    printf("Enter size of the Hash Table: ");
    scanf("%d", &n);

    ht = (int *)malloc(sizeof(int) * n);
    if (ht == NULL)
    {
        printf("Memory allocation failed\n");
        return 1;
    }

    for (i = 0; i < n; i++)
        ht[i] = 0;

    do
    {
        printf("\n--- Hash Table Menu ---\n");
        printf("1. Insert\n2. Delete\n3. Search\n4. Display\n5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &ch);

        switch (ch)
        {
        case 1:
            insert();
            break;
        case 2:
            del();
            break;
        case 3:
            search();
            break;
        case 4:
            display();
            break;
        case 5:
            printf("Exiting...\n");
            break;
        default:
            printf("Invalid choice!\n");
        }

    } while (ch != 5);

    free(ht);
    return 0;
}
