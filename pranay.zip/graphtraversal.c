#include <stdio.h>

int n;
int adj[10][10];
int visited[10];

/* DFS Traversal */
void DFS(int v)
{
    printf("%d ", v);
    visited[v] = 1;

    for (int i = 0; i < n; i++)
    {
        if (adj[v][i] == 1 && !visited[i])
            DFS(i);
    }
}

/* BFS Traversal */
void BFS(int start)
{
    int queue[10], front = 0, rear = 0;
    int visited_bfs[10] = {0};

    queue[rear++] = start;
    visited_bfs[start] = 1;

    while (front < rear)
    {
        int v = queue[front++];
        printf("%d ", v);

        for (int i = 0; i < n; i++)
        {
            if (adj[v][i] == 1 && !visited_bfs[i])
            {
                queue[rear++] = i;
                visited_bfs[i] = 1;
            }
        }
    }
}

int main()
{
    int start, choice;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &adj[i][j]);

    printf("Enter starting vertex: ");
    scanf("%d", &start);

    printf("\n1. DFS Traversal\n2. BFS Traversal\n");
    printf("Enter choice: ");
    scanf("%d", &choice);

    if (choice == 1)
    {
        printf("DFS Traversal: ");
        DFS(start);
    }
    else if (choice == 2)
    {
        printf("BFS Traversal: ");
        BFS(start);
    }
    else
    {
        printf("Invalid choice\n");
    }

    return 0;
}
