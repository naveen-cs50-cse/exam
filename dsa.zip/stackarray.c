#inclide<stdio.h> 
#include<stdlib.h>  
int *stack,size,top=-1;  
int isempty();  
int isfull();  
void push(int);  
int pop();  
void display();  
void topelement();  
int main()  
{  
int ch,x;  
printf("enter initial size of the stack: ");  
scanf("%d",&size);  
stack=(int*)calloc(sizeof(int),size);  
do  
{ 
printf("1.PUSH 2.POP 3.TOP ELEMENT 4.DISPLAY 5.EXIT 
\n"); printf("PLEASE ENTER YOUR CHOICE : ");  
scanf("%d",&ch);  
switch(ch)  
{  
case 1 :printf("ENTER THE ELEMENT :\n");  
scanf("%d",&x);  
push(x);  
break;  
case 2 :x=pop();  
if(x==0)  
printf("STACK UNDERFLOW !\n");  
else  
printf("POPPED ELEMENT IS %d \n",x);  
break;  
case 3 : topelement();  
break;  
case 4 : display();  
break;  
default : printf("INVALID INPUT !\n"); 
}  
}while(ch>0 && 
ch<5); free(stack);  
return 0;  
}  
int isfull()  
{  
if(top == size-1)  
return 1;  
else  
return 0;  }
int isempty()  
{  
if(top == -1)  
return 1;  
else  
return 0;  
}  
void push(int e)  
{  
if(isfull()) 
{  
stack=(int*)realloc(stack,2*size);  
printf("size of the stack is increased\n"); }  
top++;  
stack[top]=e;  
printf("%d is pushed into the stack\n",e); }  
int pop()  
{  
if(isempty())  
{   
return 0;}  
int x=stack[top];  
top--;  
return x;  
}  
void topelement()  
{  
if(isempty())  
printf("STACK IS EMPTY !"); 
else  
printf("Top Element element is %d \n",stack[top]);  
}  
void display()  
{  
if(isempty())  
{  
printf("STACK IS EMPTY ! \n");  
}  
printf("STACK ELEMENTS ARE : \n");  
for(int i=top;i>=0;i--)  
printf("%d\n",stack[i]);  
}  