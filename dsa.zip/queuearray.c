#include <stdio.h>  
#include <stdlib.h>  
#define SIZE 5 
int queue[SIZE];  
int front = -1, rear = -1;  
void enqueue(int ele)  
{   
if (rear == SIZE - 1){  
printf("Queue is Full \n");  
} 
else{
if (front == -1)  
front = 0;  
rear++;  
queue[rear] = ele;  
printf("%d inserted ele into the queue.\n", ele); }  
}  
void dequeue()  
{    
if (front == -1 | front > rear) {  
printf("Queue is Empty \n"); 
}
else{
printf("%d deleted ele from the queue.\n", 
queue[front]); front++;  
} 
} 
void display() {  
if (front == -1 | front > rear) {  
printf("Queue is Empty\n");  
}  
else  
{  
printf("\nQueue elements are: ");  
for (int i = front; i <= rear; i++)  
{  

printf("%d ", queue[i]);  
}  
printf("\n");  
} } 
int main()  
{  
int ch, ele;  
while (1) {  
printf("\n----- Queue Operations -----\n");  
printf("1. Enqueue\n2. Dequeue\n3. Display\n4. Exit\n");
 printf("Enter your choice: ");  
scanf("%d", &ch);  
switch (ch) {  
case 1:  
printf("Enter value to insert: ");  
scanf("%d", &ele);  
enqueue(ele);  
break;  
case 2:  
dequeue();  
break;  
case 3: 
display();  
break;  
case 4:  
printf("Exiting program.\n");  
exit(0);  
default:  
printf("Invalid choice! Please try again.\n");  
}  
}  
return 0;  
} 