#include<stdio.h>  
#include<stdlib.h>  
#include<ctype.h>  
#include<math.h>  
#define MAX 30  
int stack[MAX];  
int top=-1;  
char pop();  
void evaluate(char *);  
void push(char x)  
{ if(top!=MAX-1) 
{  
top++;  
stack[top]=x;  
} }  
char pop()  
{ char x;  
if(top!=-1)  
{ x=stack[top];  
top--;  
return x;  
} }  
int isempty()  
{ if(top==-1)  
return 1;  
else  
return 0;  
}  
void evaluate(char *a) 
{
     int i;  
     char ch;  
     int op1,op2;  
for(i=0;a[i]!='\0';i++) 
{ ch=a[i];  
if(isdigit(ch))  
push(ch-48);  
else  
{ switch(ch){  
case '$':op2=pop();  
op1=pop();  
push(pow(op1,op2));  
break;  
case '*':op2=pop();  
op1=pop();  
push(op1*op2);  
break;  
case '/':op2=pop();  
op1=pop();  
push(op1/op2);  
break;  
case '%':op2=pop();  
op1=pop();  
push(op1%op2);  
break;  
case '+':op2=pop(); 
op1=pop();  
push(op1+op2);  
break;  
case'-':op2=pop();  
op1=pop();  
push(op1-op2);  
break;  
default:printf("wrong input\n");  
} } }  
printf("result=%d\n",pop());  
}  
void main()  
{ char p[20];  
printf("enter a postfix expression with digits as 
operands\n"); scanf("%s",p);  
evaluate(p);  
}  