#include <stdio.h> 
#include <stdlib.h> 
 
struct node { 
    int data; 
    struct node* next; 
}; 
 
 
struct node* front = NULL; 
struct node* rear = NULL; 
 
 
void enqueue(int ele) { 
    struct node* newnode = (struct node*)malloc(sizeof(struct node)); 
    newnode->data = ele; 
    newnode->next = NULL; 
 
    if (front == NULL) { 
         
        front = rear = newnode; 
    } 
 else 
 { 
        rear->next = newnode; 
        rear = newnode; 
    } 
    printf("%d inserted  to queue.\n", ele); 
} 
 
 
void dequeue() { 
    if (front == NULL) { 
        printf("Queue is empty\n"); 
        return; 
    } 
    struct node* temp = front; 
    printf("%d deleted  from queue\n", front->data); 
 
    front = front->next; 
    free(temp); 
 
    if (front == NULL) { 
        rear = NULL;   
    } 
} 
void peek() { 
    if (front == NULL) { 
        printf("Queue is empty.\n"); 
        return; 
    } 
    printf("Front element: %d\n", front->data); 
} 
void display() { 
    if (front == NULL)  
{ 
        printf("Queue is empty.\n"); 
        return; 
    } 
 
    struct node* temp = front; 
    printf("Queue: "); 
    while (temp != NULL) { 
        printf("%d ", temp->data); 
        temp = temp->next; 
    } 
    printf("\n"); 
} 
 
int main() { 
    int ch, ele; 
 
    while (1) { 
        printf("\n***Queue Menu ***\n"); 
        printf("1. Enqueue\n2.Dequeue\n3.Peek\n4.Display\n5.Exit\n"); 
       printf("Enter your choice: "); 
        scanf("%d", &ch); 
   switch (ch)  
{ 
        case 1: 
            printf("Enter value to insert: "); 
            scanf("%d", &ele); 
            enqueue(ele); 
            break; 
        case 2: 
            dequeue(); 
            break; 
        case 3: 
            peek(); 
            break; 
        case 4: 
            display(); 
            break; 
        case 5: 
            printf("Exiting...\n"); 
            exit(0); 
        default: 
            printf("Invalid choice! Please try again.\n"); 
        } 
    } 
    return 0; 
}