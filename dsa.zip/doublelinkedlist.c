#include <stdio.h> 
#include <stdlib.h> 
 
struct node { 
    int data; 
    struct node* prev; 
    struct node* next; 
}; 
 
struct node* head = NULL; 
void insertBeg(int ele) { 
    struct node* newnode = (struct node*)malloc(sizeof(struct node)); 
    newnode->data=ele; 
    if (head == NULL) 
    { 
        head = newnode; 
        return; 
    } 
    newnode->next = head; 
    head->prev = newnode; 
    head = newnode; 
} 
 
 
void insertEnd(int ele) { 
    struct node* newnode =(struct node*)malloc(sizeof(struct node)); 
    newnode->data=ele; 
    if (head == NULL) { 
        head = newnode; 
        return; 
    } 
    struct node* temp = head; 
    while (temp->next != NULL) 
        temp = temp->next; 
    temp->next = newnode; 
    newnode->prev = temp; 
} 
 
void insertPos(int ele, int pos) { 
    if (pos == 1) { 
        insertBeg(ele); 
        return; 
    } 
 
    struct node* temp = head; 
    for (int i = 1; i < pos - 1 && temp != NULL; i++) 
        temp = temp->next; 
 
    if (temp == NULL) { 
        printf("Position out of bounds!\n"); 
        return; 
    } 
 
    struct node* newnode = (struct node*)malloc(sizeof(struct node)); 
    newnode->data=ele; 
    newnode->next = temp->next; 
    newnode->prev = temp; 
 
    if (temp->next != NULL) 
        temp->next->prev = newnode; 
 
    temp->next = newnode; 
} 
 
 
void deleteBeg() { 
    if (head == NULL) { 
        printf("List is empty!\n"); 
        return; 
    } 
    struct node* temp = head; 
    head = head->next; 
 
    if (head != NULL) 
        head->prev = NULL; 
 
    free(temp); 
} 
 
void deleteEnd() { 
    if (head == NULL) { 
        printf("List is empty!\n"); 
        return; 
    } 
    struct node* temp = head; 
 
    if (temp->next == NULL) { 
        head = NULL; 
        free(temp); 
        return; 
    } 
 
    while (temp->next != NULL) 
        temp = temp->next; 
 
    temp->prev->next = NULL; 
    free(temp); 
} 
void deletePos(int pos) { 
    if (head == NULL) { 
        printf("List is empty!\n"); 
        return; 
    } 
 
    struct node* temp = head; 
 
    if (pos == 1) { 
        deleteBeg(); 
        return; 
    } 
 
    for (int i = 1; i < pos && temp != NULL; i++) 
        temp = temp->next; 
 
    if (temp == NULL) { 
        printf("Position not found!\n"); 
        return; 
    }   
 
    if (temp->next != NULL) 
        temp->next->prev = temp->prev; 
 
    if (temp->prev != NULL) 
        temp->prev->next = temp->next; 
 
    free(temp); 
} 
 
 
void displayForward() { 
    struct node* temp = head; 
    printf("List: "); 
    while (temp != NULL) { 
        printf("%d ", temp->data); 
        temp = temp->next; 
    } 
    printf("\n"); 
} 
 
 
void displayBackward() 
{ 
    if (head == NULL) 
    { 
        printf("List is empty!\n"); 
        return; 
    } 
    struct node* temp = head; 
    while (temp->next != NULL) 
        temp = temp->next; 
 
    printf("List: "); 
    while (temp != NULL) { 
        printf("%d ", temp->data); 
        temp = temp->prev; 
    } 
    printf("\n"); 
} 
 
int main() { 
    int ch, ele, pos; 
 
    while (1) { 
        printf("\n*** Doubly Linked List Menu ***\n"); 
        printf("1. Insert at Beginning\n2.Insertion at end\n3.Insertion at 
specific position\n4.Deletion at the beginning\n5.Deletion at 
end\n6.Deletion at position\n7.Display forward\n8.Display 
backward\n9.Exit\n"); 
         
       printf("Enter choice: "); 
        scanf("%d", &ch); 
 
        switch (ch) { 
            case 1: 
                printf("Enter value: "); 
                scanf("%d", &ele); 
                insertBeg(ele); 
                break; 
 
            case 2: 
                printf("Enter value: "); 
                scanf("%d", &ele); 
                insertEnd(ele); 
                break; 
 
            case 3: 
                printf("Enter value and position: "); 
                scanf("%d %d", &ele, &pos); 
                insertPos(ele, pos); 
                break; 
 
            case 4: 
                deleteBeg(); 
                break; 
 
            case 5: 
                deleteEnd(); 
                break; 
 
            case 6: 
                printf("Enter position: "); 
                scanf("%d", &pos); 
                deletePos(pos); 
                break; 
 
            case 7: 
                displayForward(); 
                break; 
 
            case 8: 
                displayBackward(); 
                break; 
 
            case 9: 
                exit(0); 
 
            default: 
                printf("Invalid choice!\n"); 
        } 
    } 
 
    return 0; 
}