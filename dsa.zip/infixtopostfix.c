#include<stdio.h>  
#include<stdlib.h>  
#include<string.h>  
#include<ctype.h>  
#define MAX 30  
char stack[MAX];  
int top; 
void push(char);  
char pop();  
void 
infixtopostfix(char*); int 
priority(char ch); void 
push(char x)  
{ if (top != MAX-1) 
{  
top++;  
stack[top] = x;  
} }  
char pop()  
{ char x;  
if(top!=-1)  
{  
x = stack[top];  
top--;  
return x;  
} }  
int isempty()  
{ if (top==-1)  
return 1;  
return 0; 
}  
int priority(char ch);  
// infix to postfix conversion  
void infixtopostfix(char *a)  
{ int x,j=0;  
char b[20]; //for storing resultant postfix 
expression int len=strlen(a);  
for(int i=0;i<len;i++)  
{ char ch=a[i];  
if(isalnum(ch)) //if a[i] is operand  
b[j++]=ch;  
else if(ch=='(')  
push(ch);  
else if(ch==')')  
{ while(stack[top]!='(')  
b[j++]=pop();  
pop(); //popping '('  
}  
else //if a[i] is operator  
{  
if(ch=='(' | isempty()) //if stack top has '(' or stack is 
empty push(ch); 
else  
{  
while(priority(ch)<=priority(stack[top])
 ) b[j++]=pop();  
push(ch);  
} }  
}//end of for  
while(isempty()==0)  
b[j++]=pop();  
b[j]='\0';  
printf("postfix expression is.: 
%s",b); }  
int priority(char ch)  
{  
switch(ch)  
{  
case '$':return(3);  
case '*':  
case '/':  
case '%':return(2);  
case '+':  
case '-':return(1); 
} }  
int main()  
{  
char p[20];  
printf("enter proper infix expression : ");  
scanf("%s",p);  
infixtopostfix(p);  
return 0;  
}  