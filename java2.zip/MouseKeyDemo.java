import java.awt.*;
import java.awt.event.*;

public class MouseKeyDemo extends Frame
        implements MouseListener, KeyListener {

    MouseKeyDemo() {
        addMouseListener(this);
        addKeyListener(this);
        setSize(300,300);
        setVisible(true);
    }

    public void mouseClicked(MouseEvent e) {
        System.out.println("Mouse clicked");
    }
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    public void keyPressed(KeyEvent e) {
        System.out.println("Key pressed");
    }
    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
        new MouseKeyDemo();
    }
}
