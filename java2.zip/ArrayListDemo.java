import java.util.ArrayList;
import java.util.Scanner;
public class ArrayListDemo
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        ArrayList list=new ArrayList();
        System.out.println("List="+list);
        list.add(10);
        list.add(20);
        list.add(33.3);
        list.add(2.1);
        list.add("java");
        System.out.println("List after insertion="+list);
        System.out.println("Enter a positive index to fetch an item:");
        int i=sc.nextInt();
        System.out.println("Element at "+i+"="+list.get(i));
        System.out.println("Enter a positive index to remove item:");
        i=sc.nextInt();
        list.remove(i);
        System.out.println("List after removing "+i+"="+list);
        list.set(i, 100);
        System.out.println("List after updating value at "+i+"="+list);
        list.clear();
        System.out.println("Now list="+list);
    }
}