import java.awt.*;

public class ComponentsDemo extends Frame {
    ComponentsDemo() {
        setLayout(new FlowLayout());

        add(new Label("Name"));
        add(new TextField(10));
        add(new TextArea(3,20));

        CheckboxGroup cbg = new CheckboxGroup();
        add(new Checkbox("Male", cbg, true));
        add(new Checkbox("Female", cbg, false));

        Choice c = new Choice();
        c.add("Java"); c.add("Python");
        add(c);

        setSize(400,300);
        setVisible(true);
    }

    public static void main(String[] args) {
        new ComponentsDemo();
    }
}
