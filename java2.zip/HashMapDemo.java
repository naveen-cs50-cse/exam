import java.util.*;
public class HashMapDemo
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        HashMap hm=new HashMap();
        System.out.println("HashMap:"+hm);
        hm.put(121, "john");
        hm.put(156, "smith");
        hm.put(101, "Dennis");
        hm.put(145, "James");
        System.out.println("HashMap:"+hm+",size="+hm.size());
        System.out.println("Enter a key to fetch its value:");
        int key=sc.nextInt();
        System.out.println("Value for "+key+":"+hm.get(key));
        hm.replace(101, "Rossum");
        System.out.println("HashMap after replacing 101:"+hm);
        hm.remove(101);
        System.out.println("HashMap after removing 101:"+hm);
        System.out.println("Enter a key to check if it exists or not:");
        int searchKey=sc.nextInt();
        boolean b=hm.containsKey(searchKey);
        System.out.println("Search status="+b);
        hm.clear();
        System.out.println("HashMap:"+hm+",size="+hm.size());
    }
}