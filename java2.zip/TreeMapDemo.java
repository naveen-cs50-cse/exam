import java.util.Scanner;
import java.util.TreeMap;
public class TreeMapDemo
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        TreeMap tm=new TreeMap();
        System.out.println("TreeMap:"+tm);
        tm.put(121, "john");
        tm.put(156, "smith");
        tm.put(101, "Dennis");
        tm.put(145, "James");
        System.out.println("TreeMap:"+tm+",size="+tm.size());
        System.out.println("Enter a key to fetch its value:");
        int key=sc.nextInt();
        System.out.println("Value for "+key+":"+tm.get(key));
        System.out.println("First entry in Treemap:"+tm.firstEntry());
        System.out.println("Last entry in TreeMap:"+tm.lastEntry());
        System.out.println("Higher entry than 101:"+tm.higherEntry(101));
        System.out.println("Lower entry than 145:"+tm.lowerEntry(145));
        tm.replace(101, "Rossum");
        System.out.println("TreeMap after replacing 101:"+tm);
        tm.remove(101);
        System.out.println("TreeMap after removing 101:"+tm);
        tm.clear();
        System.out.println("TreeMap:"+tm+",size="+tm.size());
    }
}