#include <stdio.h>

void main()
{
    int a[100], i, n, key, j;

    printf("enter size of an array \n");
    scanf("%d", &n); //

    printf("enter array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]); //
    }

    printf("Array elements before sorting...");
    for (i = 0; i < n; i++)
    {
        printf("%d\t", a[i]); //
    }
    printf("\n"); //

    for (i = 1; i < n; i++)
    {
        key = a[i]; //
        j = i - 1; //

        // Move elements of a[0..i-1] that are greater than key
        // to one position ahead of their current position
        while (j >= 0 && key < a[j])
        {
            a[j + 1] = a[j]; //
            j = j - 1; //
        }
        a[j + 1] = key; //
    }

    printf("Array elements after sorting......");
    for (i = 0; i < n; i++)
    {
        printf("%d\t", a[i]); //
    }
}