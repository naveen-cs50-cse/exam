import java.util.*;

class IteratorDemo{
    public static void main(String[] args) {

        ArrayList<String> list = new ArrayList<>();
        list.add("Apple");
        list.add("Banana");
        list.add("Mango");

        System.out.println("Using Iterator:");
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        System.out.println("\nUsing ListIterator (forward and backward):");
        ListIterator<String> lit = list.listIterator();
        System.out.println("Forward iteration:");
        while (lit.hasNext()) {
            System.out.println(lit.next());
        }

        System.out.println("Backward iteration:");
        while (lit.hasPrevious()) {
            System.out.println(lit.previous());
        }
    }
}
