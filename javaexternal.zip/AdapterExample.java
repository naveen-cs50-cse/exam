import java.awt.*;
import java.awt.event.*;

public class AdapterExample extends Frame {

    AdapterExample() {
        setSize(300, 200);
        setTitle("Adapter Example");
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }
    public static void main(String[] args) {
        new AdapterExample();
    }
}
