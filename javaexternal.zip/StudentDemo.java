
class Student {
     int rollNo;
    String name, branch, college;
    float cgpa;
    void displayDetails() {
        System.out.println("Student Details:");
        System.out.println("Roll Number: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Branch: " + branch);
        System.out.println("College:"+ college);
        System.out.println("cgpa:"+cgpa);
    }
}
 class StudentDemo {
    public static void main(String[] args) {

        Student s1 = new Student();
        s1.rollNo = 101;
        s1.name = "Rahul";
        s1.branch = "cse ds";
        s1.college="mvsr";
        s1.cgpa=8.5f;
        s1.displayDetails();
    }
}
