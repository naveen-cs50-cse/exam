import java.awt.*;
import java.awt.event.*;

public class AWTComponentsExample extends Frame {

    AWTComponentsExample() {
        setLayout(null);
        setSize(400, 400);
        setTitle("AWT Components Example");

        // Button
        Button b = new Button("Click Me");
        b.setBounds(50, 50, 80, 30);
        add(b);

        // TextField
        TextField tf = new TextField();
        tf.setBounds(50, 100, 200, 30);
        add(tf);

        // TextArea
        TextArea ta = new TextArea();
        ta.setBounds(50, 150, 200, 80);
        add(ta);

        // Checkbox
        Checkbox cb1 = new Checkbox("Option 1");
        cb1.setBounds(50, 250, 80, 30);
        add(cb1);

        // CheckboxGroup
        CheckboxGroup group = new CheckboxGroup();
        Checkbox cb2 = new Checkbox("Male", group, false);
        cb2.setBounds(150, 250, 60, 30);
        add(cb2);
        Checkbox cb3 = new Checkbox("Female", group, false);
        cb3.setBounds(220, 250, 70, 30);
        add(cb3);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new AWTComponentsExample();
    }
}
