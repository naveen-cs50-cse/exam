final class FinalClass {
    final int x = 10;

    final void show() {
        System.out.println("Final Method");
    }
}
class FinalDemo{
    public static void main(String[] args) {
        FinalClass f = new FinalClass();
        f.show();
        System.out.println(f.x);
    }
}
