import java.io.*;

class ByteStreamDemo {
    public static void main(String[] args) throws Exception {

        String path = System.getProperty("user.home") + "/file.txt";

        FileOutputStream fos = new FileOutputStream(path);
        fos.write("Hello Java".getBytes());
        fos.close();

        FileInputStream fis = new FileInputStream(path);
        int ch;
        while ((ch = fis.read()) != -1) {
            System.out.print((char) ch);
        }
        fis.close();
    }
}
