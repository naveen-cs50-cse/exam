class StringDemo {
    public static void main(String[] args) {
        String s = "Hello";
        s.concat(" World");
        System.out.println("String: " + s);

        StringBuffer sb = new StringBuffer("Hello");
        sb.append(" World");
        System.out.println("StringBuffer: " + sb);

        StringBuilder sb1 = new StringBuilder("Hello");
        sb1.append(" World");
        System.out.println("StringBuilder: " + sb1);
    }
}
