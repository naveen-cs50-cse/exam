class ConstructorDemo {
    ConstructorDemo() {
        System.out.println("Default Constructor");
    }

    ConstructorDemo(int a) {
        System.out.println("Parameterized Constructor: " + a);
    }
}
class ConstructorOverloadingDemo{
    public static void main (String[] args) {
       ConstructorDemo c= new ConstructorDemo();
       ConstructorDemo c1= new ConstructorDemo(100);
    }
}
