class Walking
{
    void walk(){
        System.out.println("Man walking fastly");
    }
}
class Man extends Walking{
    void walk(){
        System.out.println("Man walking slowly");
        super.walk();
    }
}
class MethodOverridingDemo{
public static void main(String args[]){
    Man obj = new Man();
    obj.walk();
}
}