import mypack.Demo;
public class UserDefinePackageDemo
{
public static void main(String args[])
{
Demo a=new Demo();
a.show();
System.out.println("show() class A");
}
}