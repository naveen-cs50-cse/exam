import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharacterStreamExample {

    public static void main(String[] args) throws IOException {

        String filePath = System.getProperty("user.home") + "/example.txt";

        FileWriter writer = new FileWriter(filePath);
        writer.write("This is a character stream example.");
        writer.close();

        FileReader reader = new FileReader(filePath);
        int ch;
        while ((ch = reader.read()) != -1) {
            System.out.print((char) ch);
        }
        reader.close();
    }
}
