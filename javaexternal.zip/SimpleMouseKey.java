import java.awt.*;
import java.awt.event.*;

public class SimpleMouseKey extends Frame implements MouseListener, KeyListener {

    Label label;

    SimpleMouseKey() {
        label = new Label("Event Info");
        label.setBounds(20, 50, 300, 20);
        add(label);

        addMouseListener(this);
        addKeyListener(this);

        setSize(300, 200);
        setLayout(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }

    public void mouseClicked(MouseEvent e) {
        label.setText("Mouse Clicked at: " + e.getX() + ", " + e.getY());
    }
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    public void keyPressed(KeyEvent e) {
        label.setText("Key Pressed: " + e.getKeyChar());
    }
    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}

    public static void main(String[] args) {
     new SimpleMouseKey();
    }
}
