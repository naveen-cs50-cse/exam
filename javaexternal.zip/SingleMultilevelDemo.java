class one{
    String name="class one";
    void displayone(){
        System.out.println("parent class "+name);
    }
}
class two extends one{
    String name2="class two";
    void displaytwo(){
        super.displayone();
        System.out.println("single level inheirtance"+name2);
    }
}
class three extends two{
    String name3="class three";
    void displaythree(){
        super.displaytwo();
        System.out.println("multilevel inherintance"+name3);
    }
}
class SingleMultilevelDemo{
    public static void main(String args[]){
        three obj=new three();
        obj.displaythree();
    }
}