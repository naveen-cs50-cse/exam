class Display {
    void show(String msg) {
        synchronized (this) {
            for (int i = 1; i <= 3; i++) {
                System.out.println(msg);
            }
        }
    }
}

class MyThreadA extends Thread {
    Display d;
    MyThreadA(Display d) {
        this.d = d;
    }
    public void run() {
        d.show("Hello");
    }
}

class MyThreadB extends Thread {
    Display d;
    MyThreadB(Display d) {
        this.d = d;
    }
    public void run() {
        d.show("Welcome");
    }
}

public class SynchronizedBlockDemo {
    public static void main(String[] args) {
        Display obj = new Display();
        MyThreadA t1=new MyThreadA(obj);
        MyThreadB t2=new MyThreadB(obj);
        t1.start(); 
        t2.start();
    }
}
