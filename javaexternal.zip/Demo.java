package mypack;
public class Demo
{
public void show()
{
System.out.println("User define package");
}
}