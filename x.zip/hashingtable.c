#include <stdio.h> 
#include <stdlib.h> 
#define TABLE_SIZE 5 
typedef struct HashEntry { 
    int key; 
    int value; 
} HashEntry; 
 
HashEntry *table[TABLE_SIZE]; 
int neverUsed[TABLE_SIZE]; 
 
int HashFunc(int key) { 
    return key % TABLE_SIZE; 
} 
 
void Insert(int key, int value) { 
    int hash = HashFunc(key); 
    int tmp = hash; 
    while (table[hash] != NULL && table[hash]->key != key) { 
        hash = HashFunc(hash + 1); 
        if (hash == tmp) { 
            printf("Table full\n"); 
            return; 
        } 
    } 
    if (table[hash] != NULL) { 
        free(table[hash]); 
    } 
    HashEntry *h = (HashEntry *)malloc(sizeof(HashEntry)); 
    h->key = key; 
    h->value = value; 
    table[hash] = h; 
    neverUsed[hash] = 0; 
} 
 
int Search(int key) { 
    int hash = HashFunc(key); 
    int tmp = hash; 
    while (!neverUsed[hash]) { 
        if (table[hash] == NULL || table[hash]->key != key) 
            hash = HashFunc(hash + 1); 
        else 
            break; 
        if (hash == tmp) 
            return -1; 

 
 
    } 
    if (neverUsed[hash]) 
        return -1; 
    else 
        return table[hash]->value; 
} 
 
void Remove(int key) { 
    int hash = HashFunc(key); 
    int tmp = hash; 
    int f = 0; 
    while (!neverUsed[hash]) { 
        if (table[hash] == NULL || table[hash]->key != key) 
            hash = HashFunc(hash + 1); 
        else 
            break; 
        if (hash == tmp) { 
            f = 1; 
            break; 
        } 
    } 
    if (neverUsed[hash] || f) { 
        printf("Element Not Found:"); 
    } else { 
        free(table[hash]); 
        table[hash] = NULL; 
        printf("Element Deleted\n"); 
    } 
} 
 
void display() { 
    for (int i = 0; i < TABLE_SIZE; i++) { 
        if (table[i] != NULL) 
            printf("[%d: %d,%d ]\n", i, table[i]->key, table[i]->value); 
        else 
            printf("[%d: , ]\n", i); 
    } 
} 
 
int main() { 
    for (int i = 0; i < TABLE_SIZE; i++) { 
        table[i] = NULL; 
        neverUsed[i] = 1; 
    } 
    int key, value; 
    int choice; 

 
    do { 
        printf("Operations on Hash Table:\n1.Insert element into the table\n2.Search element from the key\n"); 
        printf("3.Delete element with a key\n4.Display\n5.Exit\n"); 
        printf("Enter your choice: "); 
        scanf("%d", &choice); 
        switch (choice) { 
            case 1: 
                printf("Enter key to be inserted: "); 
                scanf("%d", &key); 
                printf("Enter element associated with the key: "); 
                scanf("%d", &value); 
                Insert(key, value); 
                break; 
            case 2: 
                printf("Enter key of the element to be searched: "); 
                scanf("%d", &key); 
                if (Search(key) == -1) { 
                    printf("No element found at key%d\n", key); 
                } else { 
                    printf("Element at key %d : %d\n", key, Search(key)); 
                } 
                break; 
            case 3: 
                printf("Enter key of the element to be deleted: "); 
                scanf("%d", &key); 
                Remove(key); 
                break; 
            case 4: 
                display(); 
                break; 
            default: 
                printf("\nEnter correct option\n"); 
        } 
    } while (choice >= 1 && choice <= 4); 
    for (int i = 0; i < TABLE_SIZE; i++) { 
        if (table[i] != NULL) 
            free(table[i]); 
    } 
    return 0; 
} 