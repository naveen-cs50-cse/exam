#include<stdlib.h> 
#include<stdio.h> 
typedef struct node 
{   
  int data;   
  struct node *left_child,*right_child;     
}node;   
node * root=NULL; 
void insert(int);  
void del(int); 
void search(int); 
void inorder(node*); 
int main() 
{ 
int ch,key; 
root=NULL; 
printf("Program for Binary Search Tree Operations\n");  
do 
{ 
printf("1.Create or Add\t2.Search\t3.Delete\t4.Display\n"); 
printf("Enter your choice: "); 
scanf("%d",&ch); 
switch(ch) 
{ 
case 1:printf("Enter the element: ");  
    scanf("%d",&key); 
    insert(key); 
    break; 
case 2:printf("Enter the element which u want to search: "); 
    scanf("%d",&key); 
    search(key); 
    break; 
case 3: printf("Enter the element u wish to delete: ");  
    scanf("%d",&key); 
    del(key);  
    break; 
case 4: if(root==NULL)  
                   printf("Tree is not created\n");  
            else 
               { 
                     printf("The tree is: \n");  
                     inorder(root); 
                } 
            break; 
    } 
 
 
 
}while(ch!=5); 
} 
void search(int key) 
{ 
node *cur;  
cur=root;  
while(cur!=NULL) 
{ 
if(cur->data==key) 
{ 
printf("The key %d  is present in the tree\n",cur->data);  
return; 
} 
if(cur->data>key) 
          cur=cur->left_child;  
else 
          cur=cur->right_child; 
} 
printf("The key %d  is NOT present in the tree\n",cur->data);  
}  
 
void  insert(int key) 
{ 
  node *nn= malloc(sizeof(node));   
  nn->data = key;   
  nn->left_child = NULL;   
  nn->right_child = NULL;   
    if(root==NULL) 
    {       root=nn; 
             return; 
    } 
    node* cur=root,*parent; 
    while(cur!=NULL) 
    { 
        parent=cur; 
        if(key<cur->data)   
                   cur=cur->left_child; 
      else if(key>cur->data) 
                  cur=cur->right_child; 
       else 
        { 
            printf("key already exists\n"); 
            return; 
        } 
    } 
    if(key<parent->data)
        parent->left_child=nn; 
    else 
               parent->right_child=nn; 
} 
void  del(int key) 
{ 
node* curr = root; 
node* parent = NULL; 
while (curr != NULL && curr->data != key)  
{ 
    parent = curr; 
   if (key < curr->data) 
            curr = curr->left_child; 
   else 
            curr = curr->right_child; 
} 
if (curr == NULL) 
{ 
         printf("key not found in the BST\n"); 
         return ; 
} 
node *temp; 
 
if (curr->left_child == NULL || curr->right_child == NULL)  
{ 

    if (curr->left_child == NULL) 
             temp = curr->right_child; 
    else 
             temp = curr->left_child; 

    if (parent == NULL) 
             root=temp; 

    if (curr == parent->left_child) 
             parent->left_child = temp; 
    else 
             parent->right_child = temp; 
 
    free(curr); 
} 
    
else 
{ 
    parent = NULL; 
    node *inorder_succ; 
     
    inorder_succ = curr->right_child; 
    while (inorder_succ->left_child != NULL) 
    { 
        parent = inorder_succ; 
        inorder_succ = inorder_succ->left_child; 
    } 
   
    if (parent != NULL) 
             parent->left_child = inorder_succ->right_child; 
   
    else 
            curr->right_child = inorder_succ->right_child; 
   curr->data = inorder_succ->data; 
    free(inorder_succ); 
 } 
 printf("node is deleted\n"); 
 } 
 void inorder(struct node *root) 
{   
 if (root != NULL)    
  {   
        inorder(root->left_child);    
        printf(" %d ", root->data);    
        inorder(root->right_child);    
  }   
}  